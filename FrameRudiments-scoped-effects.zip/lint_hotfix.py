"""Correct the eight Ruff findings in the 161-renderer batch without changing output.

The migration is idempotent. Refuse ambiguous/nonbaseline code instead of
blindly rewriting user changes or silently skipping lint problems.
"""
import io
import tokenize

ONE_LINE_IFS = (
    '                if n>1:draw.line(pts,fill=self._ink(0),width=self.line_width)',
    '                if len(p2)>1:draw.line(p2,fill=self._ink(0),width=self.line_width)',
    '            if len(coords)>1:draw.line(coords,fill=self._ink(0),width=self.line_width)',
)


def fix_renderers(source):
    eol = "\r\n" if "\r\n" in source else "\n"
    source = source.replace("\r\n", "\n")
    offsets = [0]
    for row in source.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(row))
    edits = []
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type == tokenize.NAME and token.string == "l":
            a = offsets[token.start[0] - 1] + token.start[1]
            b = offsets[token.end[0] - 1] + token.end[1]
            edits.append((a, b))
    remaining = [row for row in ONE_LINE_IFS if row in source]
    if not edits and not remaining:
        return source.replace("\n", eol)
    if len(edits) != 30 or len(remaining) != 3:
        raise ValueError("Renderer lint baseline changed; review before applying corrections")
    for a, b in reversed(edits):
        source = source[:a] + "left" + source[b:]
    for old in ONE_LINE_IFS:
        if source.count(old) != 1:
            raise ValueError("Renderer one-line-if no longer uniquely matches baseline")
        indentation = old[:len(old) - len(old.lstrip())]
        head, statement = old.strip().split(":", 1)
        source = source.replace(old, indentation + head + ":\n" + indentation + "    " + statement)
    return source.replace("\n", eol)


def fix_catalogue(source):
    eol = "\r\n" if "\r\n" in source else "\n"
    source = source.replace("\r\n", "\n")
    early = "from dataclasses import dataclass\nfrom .effect_catalogue import EFFECT_SPECS\n"
    if early in source:
        return source.replace("\n", eol)
    if source.count("from dataclasses import dataclass\n") != 1:
        raise ValueError("Catalogue top-level imports changed")
    late = "from .effect_catalogue import EFFECT_SPECS\nEFFECT_VIEWS ="
    if source.count(late) != 1:
        raise ValueError("Catalogue late import no longer matches baseline")
    source = source.replace("from dataclasses import dataclass\n", early, 1)
    source = source.replace(late, "EFFECT_VIEWS =", 1)
    return source.replace("\n", eol)
