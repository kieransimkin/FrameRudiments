# FrameRudiments scoped compositing effects

Target: `kieransimkin/FrameRudiments` at merged effects-batch commit
`bb0a98104f8dc506da78cb9e856ac6488ea40a73` (161 renderers).

Adds isolated post effect pipelines for all compositor elements and a
finished-frame pipeline, native DanceRudiment numeric/categorical modulation,
evidence sidecars and public gallery samples. No release or branch has been
published by this patch.

## PowerShell

```powershell
git switch main
git pull --ff-only origin main
git switch -c feature/scoped-post-effects

$pkg = Join-Path $env:TEMP 'FrameRudimentsScopedEffects'
Expand-Archive .\FrameRudiments-scoped-effects.zip -DestinationPath $pkg -Force

py "$pkg\apply_scoped_effects.py" --repo . --check
py "$pkg\apply_scoped_effects.py" --repo .

python -m pip install -e '.[dev]'
python -m pytest -q --basetemp="$env:TEMP\fr-scoped-tests" tests/test_scoped_effects.py
ruff check .
git diff --check
```

The installer is idempotent, validates every update before touching any file,
preserves unrelated edits and existing EOL convention, and refuses to replace
unrecognised/new files. Do not run apply if the check fails.

```powershell
git add README.md docs/ src/ scripts/ tests/ .github/workflows/
git commit -m "Add per-element and full-frame DanceRudiment-modulated post effects"
git push -u origin feature/scoped-post-effects
```

Open a PR and wait for the repository CI and Pages build to pass before merge.
No PyPI release tag is created by these changes.
