"""Plan and apply FrameRudiments scoped post-effects, preserving unrelated edits."""
import argparse
import os
from pathlib import Path
import tempfile

from lint_hotfix import fix_renderers, fix_catalogue

HERE = Path(__file__).resolve().parent
METHOD = (HERE / "compositor-method.txt").read_text(encoding="utf-8")

# (existing file, exact old fragment, replacement, unique installed marker)
RULES = [
    ("src/framerudiments/compositor.py",
     "from .visualisers import effect_specs\n",
     "from .visualisers import effect_specs\nfrom .scoped_effects import CompositingEffects\n",
     "from .scoped_effects import CompositingEffects"),
    ("src/framerudiments/compositor.py",
     "        self.extents, self.text_states = {}, {}\n",
     """        self.extents, self.text_states = {}, {}
        targets = {"background", *(f"layer:{layer.id}" for layer in self.layers),
                   *(f"identity:{i}" for i in range(len(self.identity))),
                   *(f"lyric-art:{layer.id.rsplit('-', 1)[-1]}" for layer in self.lyric_art.values())}
        if self.scene:
            targets.add("scene")
        if self.caption:
            targets.add("caption")
        self.post_pipeline = CompositingEffects(project, project.data.get("post_effects", {}),
                                                self.context, valid_elements=targets)
""",
     "self.post_pipeline = CompositingEffects("),
    ("src/framerudiments/compositor.py",
     "    def frame(self, frame):\n",
     METHOD + "    def frame(self, frame):\n",
     "def _frame_with_post_effects(self, ctx):"),
    ("src/framerudiments/compositor.py",
     "        ctx = self.context(frame)\n        image = self.background.copy()\n",
     """        ctx = self.context(frame)
        if self.post_pipeline.enabled:
            # Final-frame opacity/rotation may leave transparent pixels. The
            # encoded RGB output uses a deterministic black matte, never an
            # implicit alpha-discard that would silently erase opacity.
            matte = Image.new("RGBA", self.background.size, "#000000")
            matte.alpha_composite(self._frame_with_post_effects(ctx))
            return matte.convert("RGB"), ctx
        image = self.background.copy()
""",
     'matte.alpha_composite(self._frame_with_post_effects(ctx))'),
    ("src/framerudiments/compositor.py",
     "    def evidence(self):\n",
     """    def post_effect_reports(self):
        return dict(self.post_pipeline.last_report) if self.post_pipeline.enabled else {}

    def evidence(self):
""",
     "def post_effect_reports(self):"),
    ("src/framerudiments/compositor.py",
     "                    custom_scene=bool(self.scene))\n",
     """                    custom_scene=bool(self.scene),
                    **({"post_effects": self.post_pipeline.evidence} if self.post_pipeline.enabled else {}))
""",
     '**({"post_effects": self.post_pipeline.evidence}'),
    ("src/framerudiments/project.py",
     '                      "identity", "effects", "stemlab_loop", "notes", "lyric_art", "canonical_lyrics"}, "project")',
     '                      "identity", "effects", "post_effects", "stemlab_loop", "notes", "lyric_art", "canonical_lyrics"}, "project")',
     '"effects", "post_effects", "stemlab_loop"'),
    ("src/framerudiments/project.py",
     '                    lyrics=self.lyrics, cues=self.cues, stemlab_loop=self.loop, effects=self.data.get("effects", []), inputs=self.inputs,',
     '''                    lyrics=self.lyrics, cues=self.cues, stemlab_loop=self.loop, effects=self.data.get("effects", []),
                    **({"post_effects": self.data["post_effects"]} if "post_effects" in self.data else {}), inputs=self.inputs,''',
     '**({"post_effects": self.data["post_effects"]}'),
    ("src/framerudiments/render.py",
     '''def _analysis(handle, compositor, context):
    reports = compositor.frame_reports()
    if reports:
        handle.write(json.dumps(dict(schema="framerudiments.rudiment-analysis-frame.v1", frame=context.frame, source_seconds=context.source_seconds,
                                     output_seconds=context.output_seconds, layers=reports), allow_nan=False) + "\\n")
''',
     '''def _analysis(handle, compositor, context):
    reports = compositor.frame_reports()
    post = compositor.post_effect_reports()
    if reports or post:
        entry = dict(schema="framerudiments.rudiment-analysis-frame.v1", frame=context.frame,
                     source_seconds=context.source_seconds, output_seconds=context.output_seconds, layers=reports)
        if post:
            entry["post_effects"] = post
        handle.write(json.dumps(entry, allow_nan=False) + "\\n")
''',
     'post = compositor.post_effect_reports()'),
    (".github/workflows/visualisation-gallery.yml",
     "      - name: Install distribution and test tooling\n",
     '''      - name: Install font for compositor effects tests
        run: |
          sudo apt-get update -qq
          sudo apt-get install -y fonts-dejavu-core
          echo 'FRAMERUDIMENTS_TEST_FONT=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf' >> "$GITHUB_ENV"
      - name: Install distribution and test tooling
''',
     "Install font for compositor effects tests"),
    (".github/workflows/visualisation-gallery.yml",
     "        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py\n",
     "        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py\n",
     "tests/test_effect_batch.py tests/test_scoped_effects.py"),
    (".github/workflows/visualisation-gallery.yml",
     " src/framerudiments/post_effects.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py\n",
     " src/framerudiments/post_effects.py src/framerudiments/scoped_effects.py scripts/generate_post_effect_gallery.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py\n",
     "src/framerudiments/scoped_effects.py scripts/generate_post_effect_gallery.py"),
    (".github/workflows/visualisation-gallery.yml",
     "        run: python scripts/generate_visualisation_gallery.py --output _site\n",
     "        run: python scripts/generate_visualisation_gallery.py --output _site\n"
     "      - name: Generate isolated element and full-frame effects gallery\n"
     "        run: python scripts/generate_post_effect_gallery.py --output _site\n",
     "Generate isolated element and full-frame effects gallery"),
    (".github/workflows/visualisation-gallery.yml",
     "          assert (p / 'index.html').is_file() and (p / '.nojekyll').exists()\n",
     "          assert (p / 'index.html').is_file() and (p / '.nojekyll').exists()\n"
     "          assert (p / 'scopes/index.html').is_file()\n"
     "          assert (p / 'scopes/examples.json').is_file()\n"
     "          assert len(list((p / 'scopes').glob('*/*.png'))) == 24\n",
     "assert (p / 'scopes/index.html').is_file()"),
    ("docs/project-format.md",
     "## Optional full-frame effects\n",
     """## Scoped compositor post effects

The optional top-level `post_effects` object assigns ordered, deterministic
`VisualStyle` effect stages to individual components (`background`, `scene`,
`layer:ID`, `identity:N`, `caption`, `lyric-art:N`) using `elements`, to all
individual elements using `all_elements`, or to the completed composited frame
using `frame`. Every numeric effect setting accepts a source-clocked independent
DanceRudiment modulator; palettes and gradient settings use native-driven
categorical `choices`. See [scoped-post-effects.md](scoped-post-effects.md).
Stages run before the optional full-frame Butterchurn/projectM `effects` chain.
The original compositor pixel path remains unchanged when no post effects are
configured.

## Optional full-frame effects
""",
     "## Scoped compositor post effects"),
    ("README.md",
     "Enable Settings → Pages → GitHub Actions as the repository publication source.\n",
     """Enable Settings → Pages → GitHub Actions as the repository publication source.

## Per-element and full-frame post-render effects

The new `post_effects` project field supports isolated effects for **each**
background, scene, sprite, legacy bars, Rudiment layer, identity caption or
lyric-art element, and separate passes over the **finished frame**. All 161
renderers and the shared gradients/CRT/colour post effects are supported. Numeric
parameters use native DanceRudiment modulation; palettes, colour-stop sets and
gradient modes can switch between validated alternatives. Independent layer
passes cannot recolour already composited neighbours, while a frame pass can
act on everything. These stages run before the existing optional
Butterchurn/projectM feedback chain. See the [compositor effects reference](docs/scoped-post-effects.md)
and the [public scopes gallery](https://kieransimkin.github.io/FrameRudiments/scopes/).
""",
     "## Per-element and full-frame post-render effects"),
]

# Full-line anchors for both the strict installer and standalone Git patch.
_ci_prefix = ("        run: ruff check scripts/generate_visualisation_gallery.py "
              "src/framerudiments/advanced_renderers.py src/framerudiments/circular_renderers.py "
              "src/framerudiments/visualisation_catalogue.py src/framerudiments/visual_style.py "
              "src/framerudiments/modulation.py src/framerudiments/effect_catalogue.py "
              "src/framerudiments/effect_renderers.py")
_path, _old, _new, _sentinel = RULES[11]
RULES[11] = (_path, _ci_prefix + _old, _ci_prefix + _new, _sentinel)
for _i in (6, 7):
    _path, _old, _new, _sentinel = RULES[_i]
    RULES[_i] = (_path, _old + "\n", _new + "\n", _sentinel)

CREATED = (
    "src/framerudiments/scoped_effects.py",
    "tests/test_scoped_effects.py",
    "docs/scoped-post-effects.md",
    "scripts/generate_post_effect_gallery.py",
)


def plan(root):
    updates = {}
    actions = []
    for path, old, new, sentinel in RULES:
        if old == new:
            raise ValueError(f"Invalid no-op rule for {path}")
        file = root / path
        if not file.is_file():
            raise ValueError(f"Missing baseline file {path}")
        data = updates.get(path)
        if data is None:
            raw = file.read_bytes()
            if b"\0" in raw:
                raise ValueError(f"Binary input {path}")
            data = raw.decode("utf-8")
        eol = "\r\n" if "\r\n" in data else "\n"
        norm = data.replace("\r\n", "\n")
        if sentinel in norm:
            if path not in updates:
                updates[path] = data
            actions.append((path, "already-applied"))
            continue
        if norm.count(old) != 1:
            raise ValueError(f"Patch context for {path} not unique/missing: {old[:90]!r}")
        norm = norm.replace(old, new, 1)
        data = norm.replace("\n", eol)
        updates[path] = data
        actions.append((path, "modify"))
    for path in CREATED:
        target = root / path
        source = HERE / path
        content = source.read_bytes()
        if target.exists():
            if target.read_bytes() != content:
                raise ValueError(f"New source file already exists with different content: {path}")
            actions.append((path, "already-applied"))
        else:
            actions.append((path, "add"))
            updates[path] = content
    # Include the merged effect-batch's 8 Ruff errors in the same safe plan.
    # Unrelated edits are preserved; unexpected changes to the affected
    # render functions fail before any writes occur.
    for path, fixer in (("src/framerudiments/effect_renderers.py", fix_renderers),
                        ("src/framerudiments/visualisation_catalogue.py", fix_catalogue)):
        target = root / path
        if not target.is_file():
            raise ValueError(f"Missing effects-batch source: {path}")
        raw = target.read_bytes().decode("utf-8")
        fixed = fixer(raw)
        updates[path] = fixed
        actions.append((path, "modify" if fixed != raw else "already-applied"))
    return updates, actions


def apply(root, updates):
    # Planning validates every rule first. Write temp files, then atomically
    # replace each path; a partially applied update can be safely re-run.
    for path, data in updates.items():
        target = root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        bits = data.encode("utf-8") if isinstance(data, str) else data
        if target.is_file() and target.read_bytes() == bits:
            continue
        fd, temp = tempfile.mkstemp(dir=target.parent, prefix=".fr-effects-")
        try:
            with os.fdopen(fd, "wb") as out:
                out.write(bits)
            os.replace(temp, target)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="FrameRudiments checkout")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    if not (repo / "pyproject.toml").exists():
        parser.error("--repo must be the FrameRudiments root with pyproject.toml")
    updates, actions = plan(repo)
    for path, state in actions:
        print(f"{state:17} {path}")
    if args.check:
        print("PASS: all contexts and new-file collisions checked; no writes performed")
        return
    apply(repo, updates)
    print("Applied scoped post effects. Run pytest and ruff before committing.")


if __name__ == "__main__":
    main()
