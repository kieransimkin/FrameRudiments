"""Verify parser, patches and reverse-apply with source-anchor reconstruction."""
from pathlib import Path
import subprocess
import sys
import tempfile

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
from build_patch import build_patch, updates


def run(root, *args):
    result = subprocess.run(args, cwd=root, text=True, capture_output=True)
    if result.returncode:
        print("FAILED", args, result.stdout, result.stderr)
        result.check_returncode()
    return result


with tempfile.TemporaryDirectory() as folder:
    root = Path(folder)
    for rel in ("README.md", "docs/project-format.md", "docs/quality-effects.md",
                "src/framerudiments/project.py", "src/framerudiments/compositor.py",
                "src/framerudiments/render.py", "scripts/generate_quality_gallery.py",
                ".github/workflows/visualisation-gallery.yml", "tests/test_variable_bpm_words.py"):
        cells = {}
        for start, old, _ in updates(rel):
            for n, line in enumerate(old.splitlines()):
                previous = cells.get(start+n)
                if previous is not None and previous != line:
                    raise ValueError(f"Conflicting anchors in {rel}:{start+n}")
                cells[start+n] = line
        maxline = max(cells) + 3
        dest = root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text("".join(cells.get(n, f"# other tracked source line {n}") + "\n"
                                for n in range(1, maxline+1)), encoding="utf-8")
    run(root, "git", "init", "-q")
    patch = build_patch()
    run(root, "git", "apply", "--unidiff-zero", "--check", str(patch))
    run(root, "git", "apply", "--unidiff-zero", str(patch))
    run(root, "git", "diff", "--check")
    run(root, "git", "apply", "--unidiff-zero", "--reverse", "--check", str(patch))
    print("PASS: Git patch syntax, apply, whitespace and reversal in reconstructed source")
