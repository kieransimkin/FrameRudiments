"""Synthetic source-anchor tests; no claim of a full remote checkout."""
import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
import apply_default_antialias as installer
from patch_spec import EDITS, NEW_FILES


def git(root, *args):
    return subprocess.run(["git", *args], cwd=root, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout.strip()


with tempfile.TemporaryDirectory() as folder:
    root = Path(folder)
    for rel, entries in EDITS.items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        fragments = []
        for item in entries:
            old = item[0]
            count = item[2] if len(item) > 2 else 1
            fragments.extend([old] * count)
        target.write_text("\n# unrelated user-owned source\n".join(fragments) + "\n", encoding="utf-8")
    git(root, "init", "-q")
    git(root, "add", ".")
    git(root, "-c", "user.name=Smoke Test", "-c", "user.email=test@example.net", "commit", "-qm", "baseline")
    installer.BASE = git(root, "rev-parse", "HEAD")
    plan = installer._plan(root)
    assert len(plan) == len(EDITS) + len(NEW_FILES)
    before = {path: path.read_bytes() for path in root.rglob("*") if path.is_file() and ".git" not in path.parts}
    assert len(plan) == len(EDITS) + len(NEW_FILES)
    for file, data in plan.items():
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(data)
    assert not installer._plan(root), "Repeated apply must be idempotent"
    # Preserve a CRLF-edited source in a separate test checkout fixture.
    assert (root / NEW_FILES[0]).is_file()
    dest = root / "src/framerudiments/compositor.py"
    original = dest.read_bytes()
    dest.write_bytes(original.replace(b"_final_output", b"_CONFLICTUAL_OUTPUT"))
    try:
        installer._plan(root)
        raise AssertionError("Unexpectedly ignored conflicting user edits")
    except ValueError:
        pass
    print("PASS: dry-run plan, source edits, new files, repeat-run, conflict rejection")
