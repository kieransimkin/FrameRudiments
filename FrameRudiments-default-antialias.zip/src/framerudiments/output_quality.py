"""Default, opt-out final-frame anti-aliasing for FrameRudiments.

The existing VisualStyle.antialias stays opt-in for element effects. This
separate pass runs exactly once after composition, or after optional GPU
visualisers during an actual encode/preflight. It is deterministic and does
not resample audio, motion or subtitle timing.
"""

from PIL import Image

from .io import fields, integer, number
from .quality_effects import edge_aware_antialias


class OutputQuality:
    """Validated project-wide final-frame raster AA (enabled by default)."""

    def __init__(self, config=None):
        if config is None:
            config = {}
        fields(config, {"enabled", "antialias", "antialias_radius",
                        "antialias_threshold", "antialias_passes"}, "render_quality")
        self.enabled = config.get("enabled", True)
        if not isinstance(self.enabled, bool):
            raise ValueError("render_quality.enabled must be a boolean")
        self.strength = number(config.get("antialias", .9), "output antialias strength",
                               minimum=0, maximum=1)
        self.radius = number(config.get("antialias_radius", .75), "output antialias radius",
                             minimum=.25, maximum=3)
        self.threshold = number(config.get("antialias_threshold", .06),
                                "output antialias threshold", minimum=0, maximum=.95)
        self.passes = integer(config.get("antialias_passes", 2), "output antialias passes",
                              minimum=1, maximum=3)
        self.evidence = {
            "method": "premultiplied-RGBA edge-aware final-raster antialias",
            "enabled": self.enabled,
            "antialias": self.strength,
            "antialias_radius": self.radius,
            "antialias_threshold": self.threshold,
            "antialias_passes": self.passes,
            "applied_stage": "after composition and optional full-frame GPU visualisers, before encoding",
            "limits": "image-space smoothing, not high-resolution source supersampling",
        }

    def apply(self, image):
        """Preserve dimensions, channel mode and exact bytes when switched off."""
        if not isinstance(image, Image.Image) or image.mode not in {"RGB", "RGBA"}:
            raise ValueError("Output anti-aliasing needs a RGB or RGBA frame")
        if not self.enabled or not self.strength or image.width < 2 or image.height < 2:
            return image
        rgba = image.convert("RGBA") if image.mode == "RGB" else image
        result = edge_aware_antialias(
            rgba, strength=self.strength, radius=self.radius,
            threshold=self.threshold, passes=self.passes)
        return result.convert("RGB") if image.mode == "RGB" else result
