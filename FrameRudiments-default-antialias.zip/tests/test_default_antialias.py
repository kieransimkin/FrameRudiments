"""Default AA must apply once at final output, with a deterministic opt-out."""

import copy
import importlib.util
import os
from pathlib import Path

from PIL import Image, ImageDraw
import pytest

from framerudiments.output_quality import OutputQuality


def _sample():
    frame = Image.new("RGB", (160, 108), "#0c1329")
    draw = ImageDraw.Draw(frame)
    draw.polygon([(24, 19), (131, 27), (104, 88), (35, 75)], fill="#f5a55a")
    draw.line((7, 98, 153, 10), fill="#48efff", width=2)
    return frame


def test_high_quality_antialias_on_by_default_and_deterministic():
    original = _sample()
    quality = OutputQuality()
    assert quality.enabled and quality.passes == 2 and quality.strength > 0
    edited = quality.apply(original)
    assert edited.mode == "RGB" and edited.size == original.size
    assert edited.tobytes() != original.tobytes()
    assert edited.tobytes() == quality.apply(original).tobytes()
    assert quality.evidence["enabled"] is True
    assert edited.getpixel((0, 0)) == original.getpixel((0, 0))


def test_pixel_art_or_explicit_aa_pipeline_can_disable_final_pass():
    original = _sample()
    disabled = OutputQuality({"enabled": False})
    zero = OutputQuality({"antialias": 0})
    assert disabled.apply(original).tobytes() == original.tobytes()
    assert zero.apply(original).tobytes() == original.tobytes()
    assert disabled.evidence["enabled"] is False


@pytest.mark.parametrize("settings", [
    {"enabled": "false"}, {"antialias": -1}, {"antialias": 2},
    {"antialias_radius": 0}, {"antialias_threshold": 1},
    {"antialias_passes": 0}, {"antialias_passes": 1.5},
    {"antialias": float("nan")}, {"unknown": "shader"},
])
def test_invalid_default_aa_config_rejected(settings):
    with pytest.raises((ValueError, TypeError)):
        OutputQuality(settings)


def test_alpha_safe_for_isolated_ink_and_identity_when_disabled():
    frame = Image.new("RGBA", (90, 70))
    ImageDraw.Draw(frame).ellipse((15, 10, 76, 60), fill="#ed667c")
    rendered = OutputQuality().apply(frame)
    assert rendered.mode == "RGBA"
    assert rendered.getpixel((0, 0))[3] == 0
    assert rendered.size == frame.size
    assert OutputQuality({"enabled": False}).apply(frame).tobytes() == frame.tobytes()


@pytest.fixture
def project(tmp_path):
    if importlib.util.find_spec("dancerudiments") is None:
        pytest.skip("Full native DanceRudiments installation required")
    font = os.environ.get("FRAMERUDIMENTS_TEST_FONT")
    if not font:
        for candidate in ("C:/Windows/Fonts/arial.ttf",
                          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
            if Path(candidate).is_file():
                font = candidate
                break
    if not font:
        pytest.skip("A TTF font is required for full compositor integration")
    from framerudiments.demo import create_demo
    from framerudiments import Project
    return Project.load(create_demo(tmp_path / "aa-demo", font, width=180, height=320))


def test_compositor_aa_enabled_by_default_and_opt_out(project):
    from framerudiments import Project
    from framerudiments.compositor import Compositor
    comp = Compositor(project)
    raw, ctx = comp.frame(38, apply_quality=False)
    default, same_ctx = comp.frame(38)
    assert same_ctx == ctx
    assert default.tobytes() == project.output_quality.apply(raw).tobytes()
    assert default.tobytes() != raw.tobytes()
    opt = Project({**copy.deepcopy(project.data),
                   "render_quality": {"enabled": False}}, project.base)
    off, _ = Compositor(opt).frame(38)
    assert off.tobytes() == raw.tobytes()
    assert comp.evidence()["render_quality"]["enabled"] is True
    assert opt.summary()["render_quality"]["enabled"] is False


def test_temporal_compositor_applies_aa_only_to_combined_frame(project):
    from framerudiments import Project
    from framerudiments.compositor import Compositor
    project_with_temporal = Project({**copy.deepcopy(project.data), "post_effects": {
        "temporal": {"strength": .6, "shutter_frames": 3, "samples": 4}}}, project.base)
    comp = Compositor(project_with_temporal)
    raw, _ = comp.frame(40, apply_quality=False)
    final, _ = comp.frame(40)
    assert final.tobytes() == comp.output_quality.apply(raw).tobytes()
    comp.frame(12)
    assert comp.frame(40)[0].tobytes() == final.tobytes()


def test_preflight_saves_antialiased_final_frames(project, tmp_path):
    """Preflight stores the exact output-quality-processed composed frame."""
    if not os.environ.get("FRAMERUDIMENTS_FFMPEG"):
        pytest.skip("FFmpeg required for end-to-end preflight")
    from framerudiments.render import preflight
    result = preflight(project, tmp_path / "preflight-aa")
    assert result["composition"]["render_quality"]["enabled"] is True
    assert result["render_quality"]["enabled"] is True
    still = tmp_path / "preflight-aa" / "qa" / "source-00000000.png"
    assert still.is_file()
    from framerudiments.compositor import Compositor
    raw, _ = Compositor(project).frame(0, apply_quality=False)
    expected = project.output_quality.apply(raw)
    with Image.open(still) as recorded:
        assert recorded.convert("RGB").tobytes() == expected.tobytes()
