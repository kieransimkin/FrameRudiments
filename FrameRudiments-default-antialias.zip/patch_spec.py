"""Strict source-anchored patch for FrameRudiments PR #13 baseline.

Edits are deliberately limited to the output/compositor boundaries and docs;
per-layer VisualStyle AA stays opt-in. New code lives in output_quality.py.
"""
BASE = "56826c76eca2cc49696b483f53c6c000389a221c"

EDITS = {
 "src/framerudiments/project.py": [
  ('from .word_timing import parse_word_lrc, word_frame_ledger, assign_words_to_lines\n',
   'from .word_timing import parse_word_lrc, word_frame_ledger, assign_words_to_lines\n'
   'from .output_quality import OutputQuality\n'),
  ('                      "word_lyrics", "word_captions", "word_indicator"}, "project")',
   '                      "word_lyrics", "word_captions", "word_indicator", "render_quality"}, "project")'),
  ('        self.inputs = []\n        self.audio = dict(data["audio"])',
   '        self.inputs = []\n        self.output_quality = OutputQuality(data.get("render_quality", {}))\n'
   '        self.audio = dict(data["audio"])'),
  ('                    **({"post_effects": self.data["post_effects"]} if "post_effects" in self.data else {}), inputs=self.inputs,\n',
   '                    **({"post_effects": self.data["post_effects"]} if "post_effects" in self.data else {}),\n'
   '                    render_quality=self.output_quality.evidence, inputs=self.inputs,\n'),
 ],
 "src/framerudiments/compositor.py": [
  ('        self.project, self.scene = project, scene\n        self.effect_specs = effect_specs(project)',
   '        self.project, self.scene = project, scene\n'
   '        self.output_quality = project.output_quality\n'
   '        self.effect_specs = effect_specs(project)'),
  ('    def frame(self, frame):\n        if self.post_pipeline.temporal is not None',
   '    def _final_output(self, image, context, apply_quality):\n'
   '        # Historical shutter samples must not receive a separate AA pass.\n'
   '        if apply_quality and not getattr(self, "_temporal_sampling", False):\n'
   '            image = self.output_quality.apply(image)\n'
   '        return image, context\n\n'
   '    def frame(self, frame, *, apply_quality=True):\n'
   '        if self.post_pipeline.temporal is not None'),
  ('            return render_temporal_frame(self, frame)\n        ctx = self.context(frame)',
   '            image, context = render_temporal_frame(self, frame)\n'
   '            return self._final_output(image, context, apply_quality)\n'
   '        ctx = self.context(frame)'),
  ('            return matte.convert("RGB"), ctx\n        image = self.background.copy()',
   '            return self._final_output(matte.convert("RGB"), ctx, apply_quality)\n'
   '        image = self.background.copy()'),
  ('        return image.convert("RGB"), ctx\n\n    def frame_reports(self):',
   '        return self._final_output(image.convert("RGB"), ctx, apply_quality)\n\n'
   '    def frame_reports(self):'),
  ('        return dict(transformed_alpha_extents=self.extents, text_states=self.text_states,\n',
   '        return dict(transformed_alpha_extents=self.extents, text_states=self.text_states,\n'
   '                    render_quality=self.output_quality.evidence,\n'),
 ],
 "src/framerudiments/render.py": [
  ('                image, context = compositor.frame(n)\n',
   '                image, context = compositor.frame(n, apply_quality=False)\n', 2),
  ('                _analysis(analysis, compositor, context)\n',
   '                # Exactly one final AA pass, after optional GPU effects.\n'
   '                image = compositor.output_quality.apply(image)\n'
   '                _analysis(analysis, compositor, context)\n', 2),
 ],
 "scripts/generate_quality_gallery.py": [
  ('from framerudiments.quality_effects import TemporalShutter, linear_shutter_composite\n',
   'from framerudiments.quality_effects import TemporalShutter, linear_shutter_composite\n'
   'from framerudiments.output_quality import OutputQuality\n'),
  ('SCENES = (\n    ("raw", "Original output", {}, None, "Unfiltered vector/raster samples"),',
   'SCENES = (\n'
   '    ("default-aa", "New default: high-quality final AA", {}, None,\n'
   '     "Default two-pass edge-aware AA after composition"),\n'
   '    ("default-off", "AA disabled for pixel art", {}, None,\n'
   '     "Opt-out restores the unfiltered final frame"),\n'
   '    ("raw", "Original output", {}, None, "Unfiltered vector/raster samples"),'),
  ('            _run(n, config, temporal, modulator=mods if name == "dancerudiment" else None).save(folder / f"{k}.png")',
   '            image = _run(n, config, temporal, modulator=mods if name == "dancerudiment" else None)\n'
   '            if name == "default-aa":\n'
   '                image = OutputQuality().apply(image)\n'
   '            elif name == "default-off":\n'
   '                image = OutputQuality({"enabled": False}).apply(image)\n'
   '            image.save(folder / f"{k}.png")'),
  ('    catalogue = dict(schema="framerudiments.synthetic-quality-gallery.v1", synthetic=True,\n'
   '                     measured_audio=False, frames=list(MOMENTS),',
   '    catalogue = dict(schema="framerudiments.synthetic-quality-gallery.v1", synthetic=True,\n'
   '                     default_render_quality=OutputQuality().evidence,\n'
   '                     measured_audio=False, frames=list(MOMENTS),'),
 ],
 ".github/workflows/visualisation-gallery.yml": [
  ('tests/test_particle_engine.py tests/test_variable_bpm_words.py tests/test_rich_subtitles.py\n',
   'tests/test_particle_engine.py tests/test_variable_bpm_words.py tests/test_rich_subtitles.py '
   'tests/test_default_antialias.py\n'),
  ('scripts/generate_rich_lyric_gallery.py tests/test_rich_subtitles.py\n',
   'scripts/generate_rich_lyric_gallery.py tests/test_rich_subtitles.py '
   'src/framerudiments/output_quality.py tests/test_default_antialias.py\n'),
  ("          assert len(quality['scenes']) >= 9 and len(quality['visualisers']) >= 4\n",
   "          assert len(quality['scenes']) >= 11 and len(quality['visualisers']) >= 4\n"
   "          assert quality['default_render_quality']['enabled'] is True\n"
   "          assert {'default-aa', 'default-off'} <= {s['name'] for s in quality['scenes']}\n"),
 ],
 "docs/project-format.md": [
  ('| `word_lyrics`, `word_captions`, `word_indicator` | Word LRC source, optional word lane, and word-following sprite/effects. |',
   '| `word_lyrics`, `word_captions`, `word_indicator` | Word LRC source, optional word lane, and word-following sprite/effects. |\n'
   '| `render_quality` | Optional final-output AA override; high-quality two-pass edge AA is enabled by default. Use `{ "enabled": false }` for pixel-art or legacy raw output. |'),
 ],
 "docs/quality-effects.md": [
  ('FrameRudiments adds **opt-in, deterministic edge-aware anti-aliasing**, **subpixel directional motion blur** and a distinct **encoded-frame temporal shutter** to the existing `visual` / `post_effects` pipeline.',
   'FrameRudiments offers **opt-in per-element edge-aware anti-aliasing**, **subpixel directional motion blur** and a distinct **encoded-frame temporal shutter** in the `visual` / `post_effects` pipeline.'),
  ('Existing projects remain byte-for-byte unchanged unless the new effects are enabled.',
   'The *final output* additionally receives high-quality AA by default (a change in output pixels); disable `render_quality` to recover unfiltered output.'),
  ('## Three different effects, not interchangeable methods\n',
   '## Default high-quality output AA\n\n'
   'All projects now apply a two-pass, premultiplied-alpha edge-aware AA filter to the\n'
   '**finished RGB frame** by default, including sprites, particles, vector plots,\n'
   'captions and rich karaoke text. The render/preflight path applies it **after**\n'
   'Butterchurn/projectM when those engines are enabled, but before QA stills\n'
   'and encoding. Direct `Compositor.frame()` previews also use the same default;\n'
   'internal historical shutter samples remain unfiltered until the final merge.\n'
   'The underlying `VisualStyle` element AA stays opt-in, avoiding automatic\n'
   'per-layer and final-frame double smoothing. This is edge-aware raster AA,\n'
   '**not** 2×/4× geometric supersampling or a replacement for pixel-art nearest\n'
   'neighbour scaling. Use the override below when pixel-level accuracy matters:\n\n'
   '```json\n'
   '{"render_quality": {"enabled": false}}\n'
   '```\n\n'
   'Defaults are `enabled: true`, `antialias: 0.9`,\n'
   '`antialias_radius: 0.75`, `antialias_threshold: 0.06`, and\n'
   '`antialias_passes: 2`. They accept the same bounds as the existing visual AA\n'
   'effect. Frame-size, colour mode and source clocks are unaffected; the\n'
   'output quality configuration is recorded in the render manifest. Two\n'
   'full-resolution AA passes cost more CPU time on large/long videos.\n\n'
   '## Three different effects, not interchangeable methods\n'),
 ],
 "tests/test_variable_bpm_words.py": [
  ('    font_file = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"\n'
   '    if not Path(font_file).exists():\n'
   '        pytest.skip("Needs DejaVuSans for precise visual regression")',
   '    font_file = os.environ.get("FRAMERUDIMENTS_TEST_FONT")\n'
   '    if not font_file:\n'
   '        font_file = next((path for path in (\n'
   '            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",\n'
   '            "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf")\n'
   '            if Path(path).is_file()), None)\n'
   '    if not font_file or not Path(font_file).is_file():\n'
   '        pytest.skip("Requires an installed pinned test font")'),
 ],
 "README.md": [
  ('## Install and run\n',
   '## High-quality anti-aliasing on by default\n\n'
   'Every completed frame now receives a default **two-pass, edge-aware AA** pass\n'
   'after compositing (and after optional Butterchurn/projectM). It smooths\n'
   'sprite, vector, subtitle and particle edges without changing source timing.\n'
   'The previous per-element `visual.antialias` remains optional. To disable\n'
   'default AA for pixel art, use `"render_quality": {"enabled": false}` at\n'
   'project level. See [quality settings](docs/quality-effects.md) for tunable\n'
   'strength/radius/threshold/passes and performance notes.\n\n'
   '## Install and run\n'),
 ],
}
NEW_FILES = (
 "src/framerudiments/output_quality.py",
 "tests/test_default_antialias.py",
)
