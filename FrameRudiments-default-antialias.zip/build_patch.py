"""Build an explicit-context-independent Git patch from verified source anchors.

The safer installer in this package performs full anchor-conflict checks. This
standalone patch uses Git's --unidiff-zero compatibility mode; never use plain
git apply with it or treat reconstruction checks as a full remote CI run.
"""
from pathlib import Path

from patch_spec import BASE, EDITS, NEW_FILES

ROOT = Path(__file__).resolve().parent
HINTS = {
    "src/framerudiments/project.py": [[11], [25], [38], [183]],
    "src/framerudiments/compositor.py": [[209], [395], [398], [406], [441], [454]],
    "src/framerudiments/render.py": [[53, 88], [58, 93]],
    "scripts/generate_quality_gallery.py": [[14], [27], [124], [127]],
    ".github/workflows/visualisation-gallery.yml": [[32], [34], [68]],
    "docs/project-format.md": [[17]],
    "docs/quality-effects.md": [[3], [3], [5]],
    "README.md": [[63]],
    "tests/test_variable_bpm_words.py": [[153]],
}


def _rows(text):
    return text.splitlines()


def updates(path):
    items = EDITS[path]
    events = []
    for item, positions in zip(items, HINTS[path]):
        old, new = item[:2]
        for pos in positions:
            events.append((pos, old, new))
    # Two separate documentation phrases share the same original line.
    if path == "docs/quality-effects.md":
        assert events[0][0] == events[1][0]
        old = "FrameRudiments adds **opt-in, deterministic edge-aware anti-aliasing**, **subpixel directional motion blur** and a distinct **encoded-frame temporal shutter** to the existing `visual` / `post_effects` pipeline. Their parameters can be modulated by independent native DanceRudiments, using the source clock and bounded history already documented in [scoped post effects](scoped-post-effects.md). Existing projects remain byte-for-byte unchanged unless the new effects are enabled."
        new = old.replace(events[0][1], events[0][2]).replace(events[1][1], events[1][2])
        events = [(3, old, new), events[2]]
    return sorted(events, key=lambda item: item[0])


def build_patch():
    out = []
    for path in EDITS:
        out.append(f"diff --git a/{path} b/{path}\n--- a/{path}\n+++ b/{path}\n")
        delta = 0
        last = 0
        for line, old, new in updates(path):
            before, after = _rows(old), _rows(new)
            if line <= last:
                raise ValueError(f"Overlapping source patch hunks in {path} at {line}")
            last = line + len(before) - 1
            out.append(f"@@ -{line},{len(before)} +{line + delta},{len(after)} @@\n")
            out.extend("-" + s + "\n" for s in before)
            out.extend("+" + s + "\n" for s in after)
            delta += len(after) - len(before)
    for path in NEW_FILES:
        rows = _rows((ROOT / path).read_text(encoding="utf-8"))
        out.append(f"diff --git a/{path} b/{path}\nnew file mode 100644\n"
                   f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(rows)} @@\n")
        out.extend("+" + s + "\n" for s in rows)
    target = ROOT / "FrameRudiments-default-antialias.patch"
    target.write_text("".join(out), encoding="utf-8")
    return target


if __name__ == "__main__":
    p = build_patch()
    print(f"Created {p}, {p.stat().st_size} bytes; git apply requires --unidiff-zero")
