# FrameRudiments: default high-quality final-frame antialiasing

Target: `main` commit `56826c76eca2cc49696b483f53c6c000389a221c` (PR #13 merged).

The patch also fixes the existing Windows no-skip CI gate by using `FRAMERUDIMENTS_TEST_FONT` in the karaoke overlay test.

This package introduces an **enabled-by-default, two-pass, edge-aware final-raster AA** stage after composition and, when used, Butterchurn/projectM. It applies once to the final frame; historical samples used by the existing temporal shutter are **not** smoothed individually. The existing per-element `visual.antialias` remains opt-in. The final raster filter is not true 2×/4× supersampling; it softens existing sampled edges using premultiplied RGBA.

## Install on Windows PowerShell

Download the archive to your FrameRudiments checkout and run, from its root:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/default-hq-antialias

$pkg = Join-Path $env:TEMP 'FrameRudimentsDefaultAA'
Expand-Archive .\FrameRudiments-default-antialias.zip -DestinationPath $pkg -Force

py "$pkg\apply_default_antialias.py" --repo . --check
# Only proceed if the check reports no conflicts:
py "$pkg\apply_default_antialias.py" --repo .

python -m pip install -e ".[dev]"
python -m pytest -q --basetemp="$env:TEMP\fr-default-aa-tests" tests/test_default_antialias.py tests/test_quality_effects.py tests/test_rich_subtitles.py
ruff check .
git diff --check
```

The installer is **idempotent**, preserves CRLF line endings, refuses unrelated edits at the affected anchors, and checks the exact baseline HEAD. If that HEAD changed, do not force the patch onto a different revision: update the baseline and regenerate it.

The optional standalone `.patch` uses no-context hunks, so it requires **`git apply --unidiff-zero --check` / `git apply --unidiff-zero`**. The installer above is safer; ordinary `git apply` is not appropriate for the standalone patch.

## Configuration

No project changes are necessary. These are the global defaults:

```json
{
  "render_quality": {
    "enabled": true,
    "antialias": 0.9,
    "antialias_radius": 0.75,
    "antialias_threshold": 0.06,
    "antialias_passes": 2
  }
}
```

To preserve hard pixel-grid edges for pixel art or reproduce old raster output:

```json
{"render_quality": {"enabled": false}}
```

`render_quality` is project-level; it is separate from the optional element-scoped `visual.antialias`. Its exact settings are recorded in the project plan and composition evidence. More passes add CPU cost, especially at 1080p, 4K and long durations.

The existing quality gallery gains `default-aa` and `default-off` sample cards. After the PR merges and its Pages workflow passes, visit: <https://kieransimkin.github.io/FrameRudiments/quality/>.

## Verification boundaries

- Python compilation, strict source-anchor checks, installer dry-run/repeat/conflict checks, and Git patch apply/reversal were tested in a *reconstructed* fixture.
- 12 isolated tests passed locally; native full-compositor tests require DanceRudiments/FFmpeg in the proper checkout and are not claimed as passed.
- GitHub CI and deployment must pass on the exact patched commit before publication.
