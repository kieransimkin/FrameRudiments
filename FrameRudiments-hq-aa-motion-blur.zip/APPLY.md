# FrameRudiments — high-quality anti-aliasing and motion blur

Target repository: `https://github.com/kieransimkin/FrameRudiments`
Verified base commit: `e63284b06654e559b2b6102d7dd4489d9a4457b7` (includes the sprite expansion).

The installer does a dry-run, verifies Git blob hashes of every upstream file it will touch, checks collisions before writing, and protects unrelated user edits. It can be run again when already installed. Do **not** try to apply this patch on a checkout that predates the sprite expansion.

## PowerShell

Extract `FrameRudiments-hq-aa-motion-blur.zip` alongside your checkout, preferably to a temporary directory. From a **clean** checkout of `main`:

```powershell
git switch main
git pull --ff-only origin main
git switch -c feature/aa-motion-blur

$pkg = Join-Path $env:TEMP 'FrameRudimentsQuality'
Expand-Archive .\FrameRudiments-hq-aa-motion-blur.zip -DestinationPath $pkg -Force

py "$pkg\apply_quality_expansion.py" --repo . --check
py "$pkg\apply_quality_expansion.py" --repo .

python -m pip install -e '.[dev]'
python -m pytest -q tests/test_quality_effects.py
ruff check .
git diff --check
```

## Linux/macOS

```sh
python apply_quality_expansion.py --repo /path/to/FrameRudiments --check
python apply_quality_expansion.py --repo /path/to/FrameRudiments
```

The optional `.patch` contains the same source modifications plus new files. It is provided for source review; use the installer on Windows to avoid Git patch-context/line-ending issues.

## Highlights

- Edge-aware RGBA antialiasing with threshold, radius, passes and mix.
- Premultiplied directional shutter blur with sample count, angle, distance, trail, falloff and strength.
- Optional final-frame **temporal** linear-light shutter blur of *actual observed* prior encoded frames, respecting repeat/excerpt boundaries.
- All numeric parameters can be modulated by independent native DanceRudiments, including temporal shutter parameters.
- Isolated per-element or whole-frame spatial effects; true temporal shutter is final-frame only, before projectM / Butterchurn.
- CI-generated `/quality/` page with nine techniques and four sampled moments per configuration, displaying four different existing visualiser types. Uses only synthetic data.

The existing vector and sprite renderer sets remain untouched. No upstream audio analysis is modified.
