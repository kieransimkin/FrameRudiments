"""Safe application of FrameRudiments high-quality AA/shutter extension.

Targets a known upstream Git tree, supports --check, and never writes any
file until all paths and baseline Git blob hashes have been validated.
"""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys

BASE_COMMIT = "e63284b06654e559b2b6102d7dd4489d9a4457b7"
BASE_BLOBS = {
    "src/framerudiments/visual_style.py": "534f2cc0a8573b979ac4e95363e3e9af6bddedbb",
    "src/framerudiments/scoped_effects.py": "dd2d61b8f2984f744d416e8eb082c467cd9027ce",
    "src/framerudiments/compositor.py": "562a6791f773c9fa924baa3f8a7b8a2a6fdfb063",
    ".github/workflows/visualisation-gallery.yml": "dd85a6dd9291e5e9dd09c9d66171cc936db125af",
    "docs/project-format.md": "38c77e846867c6776f8e665605d1cd3b6253e7be",
    "docs/scoped-post-effects.md": "bfc21153b5a33e2276556e623b00f8b6fdcc2709",
    "README.md": "f89649b386e021fb9545957df0188edc890ece22",
    "scripts/generate_sprite_gallery.py": "3bd60de86c47adf581ead946fe3ab384ba41e83b",
    "tests/test_sprite_renderers.py": "da16f3a525421bf722c5a296bf0d94dd04abf273",
}
NEW_FILES = (
    "src/framerudiments/quality_effects.py",
    "scripts/generate_quality_gallery.py",
    "tests/test_quality_effects.py",
    "docs/quality-effects.md",
)


def blob_sha(data):
    payload = data.encode("utf-8")
    return hashlib.sha1(f"blob {len(payload)}\0".encode("ascii") + payload).hexdigest()


def one(text, original, replacement, path, count=1):
    found = text.count(original)
    if found != count:
        raise ValueError(f"{path}: expected {count} occurrence(s) of {original[:65]!r}, found {found}")
    return text.replace(original, replacement)


def expand(path, text):
    if path.endswith("visual_style.py"):
        text = one(text, "from .post_effects import POST_RANGES, apply_post_effects",
                   "from .post_effects import POST_RANGES, apply_post_effects\n"
                   "from .quality_effects import QUALITY_RANGES, apply_quality_effects", path)
        text = one(text, "VISUAL_RANGES.update(POST_RANGES)",
                   "VISUAL_RANGES.update(POST_RANGES)\nVISUAL_RANGES.update(QUALITY_RANGES)", path)
        text = one(text, "return apply_post_effects(image, self)",
                   "return apply_quality_effects(apply_post_effects(image, self), self)", path, count=2)
    elif path.endswith("scoped_effects.py"):
        text = one(text, "from .visual_style import VisualStyle",
                   "from .visual_style import VisualStyle\nfrom .quality_effects import TemporalShutter", path)
        text = one(text, 'fields(config, {"all_elements", "elements", "frame"}, "post_effects")',
                   'fields(config, {"all_elements", "elements", "frame", "temporal"}, "post_effects")', path)
        text = one(text, '        self.frame = build(config.get("frame", []), "frame")\n'
                   '        self.enabled = bool(self.all_elements or self.frame or any(self.elements.values()))',
                   '        self.frame = build(config.get("frame", []), "frame")\n'
                   '        self.temporal = (TemporalShutter(project, config["temporal"], context_at)\n'
                   '                         if "temporal" in config else None)\n'
                   '        self.enabled = bool(self.all_elements or self.frame or any(self.elements.values())\n'
                   '                            or self.temporal is not None)', path)
        text = one(text, '        self.files = [ref for stage in stages for ref in stage.files]\n'
                   '        project.inputs.extend(self.files)',
                   '        self.files = [ref for stage in stages for ref in stage.files]\n'
                   '        if self.temporal is not None:\n'
                   '            self.files.extend(self.temporal.files)\n'
                   '        project.inputs.extend(self.files)', path)
        text = one(text, '                             frame=[stage.evidence for stage in self.frame])',
                   '                             frame=[stage.evidence for stage in self.frame],\n'
                   '                             temporal=self.temporal.evidence if self.temporal else None)', path)
    elif path.endswith("compositor.py"):
        text = one(text, '    def frame(self, frame):\n        ctx = self.context(frame)',
                   '    def frame(self, frame):\n'
                   '        if self.post_pipeline.temporal is not None and not getattr(self, "_temporal_sampling", False):\n'
                   '            from .quality_effects import render_temporal_frame\n'
                   '            return render_temporal_frame(self, frame)\n'
                   '        ctx = self.context(frame)', path)
    elif path.endswith("visualisation-gallery.yml"):
        lines = text.splitlines(keepends=True)
        updated = []
        found = {"pytest": 0, "ruff": 0}
        for line in lines:
            if line.lstrip().startswith("run: python -m pytest -q tests/"):
                line = line.rstrip("\n") + " tests/test_quality_effects.py\n"
                found["pytest"] += 1
            if line.lstrip().startswith("run: ruff check "):
                line = (line.rstrip("\n") + " src/framerudiments/quality_effects.py "
                        "scripts/generate_quality_gallery.py tests/test_quality_effects.py\n")
                found["ruff"] += 1
            updated.append(line)
        if found != {"pytest": 1, "ruff": 1}:
            raise ValueError(f"{path}: ambiguous CI test/lint commands: {found}")
        text = "".join(updated)
        text = one(text, '      - name: Generate isolated element and full-frame effects gallery\n'
                   '        run: python scripts/generate_post_effect_gallery.py --output _site',
                   '      - name: Generate isolated element and full-frame effects gallery\n'
                   '        run: python scripts/generate_post_effect_gallery.py --output _site\n'
                   '      - name: Generate high-quality anti-aliasing and motion-blur gallery\n'
                   '        run: python scripts/generate_quality_gallery.py --output _site', path)
        text = one(text, "          assert len(list((p / 'scopes').glob('*/*.png'))) == 24",
                   "          assert len(list((p / 'scopes').glob('*/*.png'))) == 24\n"
                   "          quality = json.loads((p / 'quality/catalogue.json').read_text())\n"
                   "          assert quality['synthetic'] and not quality['measured_audio']\n"
                   "          assert len(quality['scenes']) >= 9 and len(quality['visualisers']) >= 4\n"
                   "          assert (p / 'quality/index.html').is_file()\n"
                   "          for scene in quality['scenes']:\n"
                   "              for j in range(len(quality['frames'])):\n"
                   "                  assert (p / 'quality' / scene['name'] / f'{j}.png').is_file()", path)
    elif path == "scripts/generate_sprite_gallery.py":
        text = one(text,
                   '        context_at = lambda n: SimpleNamespace(frame=n, output_seconds=n / 60,\n'
                   '            source_seconds=n / 60, beat=n / 30, lyric=None, cue=None)',
                   '        def context_at(n):\n'
                   '            return SimpleNamespace(frame=n, output_seconds=n / 60,\n'
                   '                                   source_seconds=n / 60, beat=n / 30, lyric=None, cue=None)', path)
    elif path == "tests/test_sprite_renderers.py":
        text = one(text,
                   '    context = lambda n: SimpleNamespace(frame=n, output_seconds=n / 60, source_seconds=n / 60, beat=n / 30)',
                   '    def context(n):\n'
                   '        return SimpleNamespace(frame=n, output_seconds=n / 60, source_seconds=n / 60, beat=n / 30)', path)
        text = one(text, '    pattern = lambda name: {"kind": "named", "pattern": name}',
                   '    def pattern(name):\n'
                   '        return {"kind": "named", "pattern": name}', path)
    elif path.endswith("scoped-post-effects.md") or path.endswith("project-format.md"):
        text += ("\n## High-quality anti-aliasing and motion blur\n\n"
                 "The new `visual.antialias` and `visual.motion_blur` controls can be applied "
                 "to individual elements or the finished frame and modulated with native DanceRudiments. "
                 "`post_effects.temporal` separately integrates observed past encoded frames "
                 "with a bounded historical shutter; see [quality effects](quality-effects.md) "
                 "for safe settings, constraints, and the CI gallery.\n")
    elif path == "README.md":
        text += ("\n## High-quality antialiasing and motion blur\n\n"
                 "Opt-in edge-aware antialiasing and premultiplied-alpha directional blur now "
                 "work in Rudiment `visual` settings and independent per-element or whole-frame "
                 "`post_effects` stages. Both accept native DanceRudiment modulation of all numeric "
                 "settings, including direction, shutter distance, samples, strength, thresholds, "
                 "radius and falloff. A separate `post_effects.temporal` shutter recomposes actual "
                 "observed encoded frames in linear-light RGB, bounded to the current source repeat. "
                 "It does not invent subframes or optical flow.\n\n"
                 "The [CI-generated AA and motion-blur comparison gallery]"
                 "(https://kieransimkin.github.io/FrameRudiments/quality/) combines four "
                 "existing visualiser modes with nine quality-effect configurations, four "
                 "observed moments each, and machine-readable parameters. See "
                 "[the quality-effects guide](docs/quality-effects.md).\n")
    else:
        raise ValueError(f"Unexpected file to patch: {path}")
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("."))
    parser.add_argument("--check", action="store_true", help="Verify everything without writing")
    args = parser.parse_args()
    root = args.repo.resolve()
    if not (root / "src/framerudiments/compositor.py").is_file():
        parser.error("--repo must point to a FrameRudiments checkout")
    edits = {}
    for rel, expected in BASE_BLOBS.items():
        path = root / rel
        old = path.read_text(encoding="utf-8")
        new = expand(rel, old) if blob_sha(old) == expected else None
        if new is None:
            # An already-applied patch is a no-op; never replace that file.
            markers = {
                "src/framerudiments/visual_style.py": "from .quality_effects import QUALITY_RANGES",
                "src/framerudiments/scoped_effects.py": "self.temporal = (TemporalShutter(",
                "src/framerudiments/compositor.py": "return render_temporal_frame(self, frame)",
                ".github/workflows/visualisation-gallery.yml": "Generate high-quality anti-aliasing",
                "docs/project-format.md": "## High-quality anti-aliasing and motion blur",
                "docs/scoped-post-effects.md": "## High-quality anti-aliasing and motion blur",
                "README.md": "## High-quality antialiasing and motion blur",
                "scripts/generate_sprite_gallery.py": "        def context_at(n):",
                "tests/test_sprite_renderers.py": "    def pattern(name):",
            }
            if markers[rel] not in old:
                raise ValueError(f"{rel}: Git content differs from baseline {expected[:12]}; "
                                 "refusing to overwrite upstream or local changes")
            new = old
        edits[path] = new
    payload = Path(__file__).resolve().parent
    for rel in NEW_FILES:
        source, dest = payload / rel, root / rel
        data = source.read_bytes()
        if dest.is_file() and dest.read_bytes() != data:
            raise ValueError(f"Refusing to overwrite different existing file: {rel}")
        edits[dest] = data
    if not args.check:
        import os
        # Existing-file edits are verified before this point. Atomic per-file writes.
        for path, content in edits.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            data = content.encode("utf-8") if isinstance(content, str) else content
            tmp = path.with_name(path.name + ".quality-tmp")
            tmp.write_bytes(data)
            os.replace(tmp, path)
    print(("CHECK OK" if args.check else "APPLIED") + f": {len(edits)} files; base commit {BASE_COMMIT[:12]}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, OSError) as err:
        print(f"FrameRudiments quality patch: {err}", file=sys.stderr)
        sys.exit(2)
