"""Precisely scoped modifications to upstream FrameRudiments at commit 93c3e62.

Full-file overwrites are not used: only verified, unique text anchors change.
"""

BASE_SHA = "93c3e62ff0083b0a3f83837ca0fe6852a1d5d59d"


def replace_once(text, before, after, path):
    if text.count(after) == 1:
        # Idempotency for re-running an already-applied installation.
        return text
    old_count = text.count(before)
    if old_count != 1:
        raise ValueError(f"{path}: expected one source anchor, found {old_count}: {before[:85]!r}")
    return text.replace(before, after, 1)


def change_file(path, source):
    edits = []
    if path == "src/framerudiments/advanced_renderers.py":
        edits += [
            ("from .visualisation_catalogue import ALL_VIEWS",
             "from .visualisation_catalogue import SPECTRAL_VIEWS, MOTION_VIEWS"),
            ("    for spec in ALL_VIEWS:\n        if spec.family == \"motion\":",
             "    for spec in (*SPECTRAL_VIEWS, *MOTION_VIEWS):\n        if spec.family == \"motion\":"),
        ]
    elif path == "src/framerudiments/rudiment_renderers.py":
        edits += [
            ("    register_circular_renderers(registry)\n    return registry",
             "    register_circular_renderers(registry)\n    from .effect_renderers import register_effect_renderers\n    register_effect_renderers(registry)\n    return registry"),
        ]
    elif path == "src/framerudiments/visualisation_catalogue.py":
        edits += [
            ("ALL_VIEWS = SPECTRAL_VIEWS + MOTION_VIEWS + CIRCULAR_VIEWS",
             "from .effect_catalogue import EFFECT_SPECS\n"
             "EFFECT_VIEWS = tuple(ViewSpec(*spec) for spec in EFFECT_SPECS)\n"
             "ALL_VIEWS = SPECTRAL_VIEWS + MOTION_VIEWS + CIRCULAR_VIEWS + EFFECT_VIEWS"),
        ]
    elif path == "src/framerudiments/visual_style.py":
        edits += [
            ("from .io import fields, number, integer\n",
             "from .io import fields, number, integer\nfrom .post_effects import POST_RANGES, apply_post_effects\n"),
            ("}\n_GRADIENT_MODES = {",
             "}\nVISUAL_RANGES.update(POST_RANGES)\n_GRADIENT_MODES = {"),
            ("        if not grade:\n            return image",
             "        if not grade:\n            return apply_post_effects(image, self)"),
            ("                pixels[x, y] = (*cache[key], round(a * self.opacity))\n        return image",
             "                pixels[x, y] = (*cache[key], round(a * self.opacity))\n"
             "        return apply_post_effects(image, self)"),
        ]
    elif path == "src/framerudiments/modulation.py":
        edits += [
            ('"min_peak_distance", "history_limit", "led_segments", "rings", "axis", "fill_alpha", "spokes", "sides"}',
             '"min_peak_distance", "history_limit", "led_segments", "rings", "axis", "fill_alpha", "spokes", "sides",\n'
             '                  "segments", "quantize", "stride"}'),
        ]
    elif path == "tests/test_visualisation_modulation.py":
        edits += [
            ("    assert len(names) == 101", "    assert len(names) == 161"),
            ("    assert len(ALL_VIEWS) == 96", "    assert len(ALL_VIEWS) == 156"),
            ("def test_gallery_can_generate_101_distinct_renderer_previews():",
             "def test_gallery_can_generate_161_distinct_renderer_previews():"),
        ]
    elif path == "tests/test_advanced_renderers.py":
        edits += [
            ('identity["source"]["path"].endswith(("advanced_renderers.py", "circular_renderers.py"))',
             'identity["source"]["path"].endswith(("advanced_renderers.py", "circular_renderers.py", "effect_renderers.py"))'),
            ('    assert len(manifest["style_lab"]) == 12',
             '    assert len(manifest["style_lab"]) == 20'),
        ]
    elif path == ".github/workflows/visualisation-gallery.yml":
        edits += [
            ('run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py',
             'run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py'),
            ('src/framerudiments/modulation.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py',
             'src/framerudiments/modulation.py src/framerudiments/effect_catalogue.py src/framerudiments/effect_renderers.py src/framerudiments/post_effects.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py'),
            ("          assert len(data['views']) == 101", "          assert len(data['views']) == 161"),
            ("          assert len(data['style_lab']) == 12", "          assert len(data['style_lab']) == 20"),
        ]
    elif path == "scripts/generate_visualisation_gallery.py":
        edits += [
            ('''    ("aurora-classic", "spectrum", "aurora", "vertical", "spectrum"),
)''',
             '''    ("aurora-classic", "spectrum", "aurora", "vertical", "spectrum"),
    ("crt-equalizer", "spectrum-led-matrix", "neon", "vertical", "spectrum"),
    ("city-lights", "spectrum-cityscape", "fire", "angular", "spectrum"),
    ("isometric-terrain", "spectrogram-isometric-terrain", "ocean", "diagonal", "spectrogram"),
    ("voxel-spectrum", "spectrogram-voxel-city", "synthwave", "vertical", "spectrogram"),
    ("phosphor-scope", "waveform-phosphor", "ice", "horizontal", "motion"),
    ("butterfly-scope", "waveform-butterfly", "pastel", "angular", "motion"),
    ("spectrogram-mosaic", "spectrogram-pixel-mosaic", "viridis-inspired", "checker", "spectrogram"),
    ("pulse-staircase", "waveform-signal-staircase", "sunset", "vertical", "motion"),
)'''),
            ('''        visual = {"palette": palette_name,
                  "gradient": {"mode": gradient_mode, "stops": palette_name,
                               "space": "hsv", "blend": "replace", "wrap": "repeat"}}
        root = output / "lab" / name''',
             '''        visual = {"palette": palette_name,
                  "gradient": {"mode": gradient_mode, "stops": palette_name,
                               "space": "hsv", "blend": "replace", "wrap": "repeat"}}
        new_fx = {
            "crt-equalizer": ("scanlines", [.18, .72]),
            "city-lights": ("vignette", [.15, .8]),
            "isometric-terrain": ("grain", [.04, .35]),
            "voxel-spectrum": ("chromatic_shift", [0, 5]),
            "phosphor-scope": ("edge_mix", [.02, .6]),
            "butterfly-scope": ("halftone", [.02, .7]),
            "spectrogram-mosaic": ("dither", [.02, .7]),
            "pulse-staircase": ("solarize", [.05, .9]),
        }
        if name in new_fx:
            field, interval = new_fx[name]
            controls.append(dict(id="native-post-fx", motion={"kind": "named", "pattern": "bounce"},
                                 axis="x", target=f"visual.{field}", range=interval,
                                 curve="smoothstep"))
            mods = RudimentModulations(project, controls, style_lab_frame)
        root = output / "lab" / name'''),
            ('''Twelve additional visual tests combine shared gradients, palettes, native''',
             '''Twenty additional visual tests combine shared gradients, palettes, native'''),
        ]
    elif path == "README.md":
        edits += [
            ("FrameRudiments now exposes **101 deterministic built-in Rudiment renderers**",
             "FrameRudiments now exposes **161 deterministic built-in Rudiment renderers**"),
            ('**12 annotated native DanceRudiment colour/geometry modulation scenes**.',
             '**20 annotated native DanceRudiment colour/geometry modulation scenes**.'),
            ('Enable Settings → Pages → GitHub Actions as the repository publication source.',
             '''The next generation adds **60 additional display families**: spectrum LED matrices,
cityscapes, ridgetrails and half-circle analysers; time-frequency voxel terrain,
hexagonal mosaics and slit scans; and native-value CRT, triggered, braided and
polar oscilloscope modes. Opt-in deterministic image treatments include scanlines,
pixelation, grain, vignette, edge highlights, halftone, chromatic separation,
solarisation and glitches. All these visual controls can be driven by
source-clocked DanceRudiments. See [expanded effects reference](docs/expanded-effects.md).

Enable Settings → Pages → GitHub Actions as the repository publication source.'''),
        ]
    elif path == "docs/visualisation-atlas.md":
        edits += [
            ("FrameRudiments offers **101 named built-in Rudiment renderers** (the original\nfive, the first 36 advanced views and **60 new circular/annular modes**).",
             "FrameRudiments offers **161 named built-in Rudiment renderers**: the five\noriginal views, 36 advanced plots, 60 annular modes and 60 additional effects."),
            ("CI gallery includes 101 renderer panels and 12 additional native-modulated",
             "CI gallery includes 161 renderer panels and 20 additional native-modulated"),
            ("## Supported views: spectrum and spectral history",
             '''## Further expansion: 60 spectrum/heatmap/oscilloscope visualisations

See the [Expanded Rendering Effects guide](expanded-effects.md) for all 60 new
named modes, optional CRT/dither/grain/chromatic treatments and modulation
examples. Existing annular views remain separately configurable. This expansion
changes presentation only: no new FFT, inferred phase or stereo analysis.

## Supported views: spectrum and spectral history'''),
        ]
    elif path == "docs/rudiment-renderers.md":
        edits += [
            ("of the same source alongside sprites and lyrics. There are now **101\nbuilt-ins**:",
             "of the same source alongside sprites and lyrics. There are now **161\nbuilt-ins**:"),
            ("[annular/gradient/modulation guide](annular-modulation.md).",
             "[annular/gradient/modulation guide](annular-modulation.md), and 60 extra\nspectral displays, spectrograms and waveform effects documented in\n[expanded effects](expanded-effects.md)."),
        ]
    else:
        raise ValueError(f"No edit rules for {path}")
    for before, after in edits:
        source = replace_once(source, before, after, path)
    return source


CHANGED = [
    "src/framerudiments/advanced_renderers.py",
    "src/framerudiments/rudiment_renderers.py",
    "src/framerudiments/visualisation_catalogue.py",
    "src/framerudiments/visual_style.py",
    "src/framerudiments/modulation.py",
    "tests/test_visualisation_modulation.py",
    "tests/test_advanced_renderers.py",
    ".github/workflows/visualisation-gallery.yml",
    "scripts/generate_visualisation_gallery.py",
    "README.md",
    "docs/visualisation-atlas.md",
    "docs/rudiment-renderers.md",
]

ADDED = [
    "src/framerudiments/effect_catalogue.py",
    "src/framerudiments/effect_renderers.py",
    "src/framerudiments/post_effects.py",
    "tests/test_effect_batch.py",
    "docs/expanded-effects.md",
]
