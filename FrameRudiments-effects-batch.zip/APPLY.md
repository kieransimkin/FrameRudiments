# FrameRudiments — 161-display expansion + CI registry hotfix

**Target repository:** https://github.com/kieransimkin/FrameRudiments

**Base commit:** `93c3e62ff0083b0a3f83837ca0fe6852a1d5d59d` (`Annular viz`).
Contains the required correction for the failing gallery/general CI registry
(`Renderer already registered: spectrum-annular-bars`).

The corrected registry registers:

- 5 original built-ins from `rudiment_renderers.py`
- 36 modes from `advanced_renderers.py`, via `SPECTRAL_VIEWS + MOTION_VIEWS`
- 60 circular modes from `circular_renderers.py`
- 60 newly implemented modes from `effect_renderers.py`

This produces **161 unique renderer names**. The existing `visual` pipeline also
gets **13 numeric new display post-effect parameters**, with native
DanceRudiment modulation through existing `visual.*` routing. Existing projects
with no `visual` effects retain their previous pixels.

## Windows PowerShell — safest route

From your local repository root:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/expanded-renderer-effects
```

Put `FrameRudiments-effects-batch.zip` in that folder, then:

```powershell
$dir = Join-Path $env:TEMP 'FrameRudimentsEffectsBatch'
Expand-Archive .\FrameRudiments-effects-batch.zip -DestinationPath $dir -Force

py "$dir\apply_renderer_batch.py" --repo . --check
py "$dir\apply_renderer_batch.py" --repo .

python -m pip install -e '.[dev]'
python -m pytest -q --basetemp="$env:TEMP\fr-effects-tests" `
    tests/test_advanced_renderers.py `
    tests/test_visualisation_modulation.py `
    tests/test_effect_batch.py
ruff check .
git diff --check
```

The installer plans **all 17 file changes** before writing, preserves original
CRLF/LF line endings of modified files, refuses to overwrite an unexpected new
file, keeps unrelated local edits, and is idempotent. If `--check` fails, do not
run the apply step. Send its full error and `git status --short` for targeting.

For a clean baseline, `git apply --check FrameRudiments-effects-batch.patch`
then `git apply FrameRudiments-effects-batch.patch` is available, but the
installer is recommended if your checkout has CRLF or unrelated edits.

### Commit and push

```powershell
git add .github/workflows/visualisation-gallery.yml README.md docs/ scripts/ src/ tests/
git commit -m "Fix annular CI and expand Rudiment views to 161"
git push -u origin feature/expanded-renderer-effects
```

Open a PR to `main`, review and merge if full CI succeeds. Do not tag/publish a
release or overwrite existing public Pages without verified successful checks.

## Emergency hotfix only

If you want CI green before applying the expansion:

```powershell
git apply --check "$dir\FrameRudiments-annular-CI-hotfix.patch"
git apply "$dir\FrameRudiments-annular-CI-hotfix.patch"
```

That hotfix changes *only* `advanced_renderers.py` to avoid registering annular
modes in both factories. If you apply it first, use the **installer**, not the
full Git patch, for the expansion (the installer detects already applied edits).

## Evidence / limitations

- Original failures verified at workflows `38962927661` and `38962927788`: all
  have the same underlying duplicate `spectrum-annular-bars` registration.
- 161-name registry / 60 new modes integration harness: passed.
- New effect batch tests in local integration harness: **85 passed**.
- CI gallery generator in local integration harness: produced **161 × 4 preview
  images**, plus **20 × 4** colour/modulation images, catalogue and HTML.
- Git patch dry-run, apply and `git diff --check` on reconstructed exact-text
  baseline fixture: passed.
- Installer dry-run, apply, idempotency: passed.
- **Not yet verified**: full FrameRudiments pytest/ruff/wheel checks against all
  released native DanceRudiments dependencies; exact-head GitHub Actions;
  GitHub Pages deployment and music/perceptual quality approval.
- The gallery uses synthetic data only; actual frequency views still require
  pinned StemLab Fourier provenance and calibrated band values.

Sources and methodology: `docs/expanded-effects.md`.
