#!/usr/bin/env python3
"""Safe Windows/Linux installer for FrameRudiments renderer batch (161 views).

Usage from a FrameRudiments checkout:
  py apply_renderer_batch.py --repo . --check
  py apply_renderer_batch.py --repo .

No unverified overwrite, broad regex edits, or automatic Git actions. Reads
and stages all 17 files before writing any of them. Preserve CRLF files.
"""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys

from change_rules import BASE_SHA, CHANGED, ADDED, change_file


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(repo, args):
    result = subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True, check=True)
    return result.stdout.strip()


def install(repo, dry_run):
    root = Path(repo).resolve()
    if not (root / "pyproject.toml").is_file() or not (root / ".git").exists():
        raise ValueError("--repo must point to a local FrameRudiments Git checkout")
    if run(root, ["rev-parse", "--show-toplevel"]).replace('\\', '/').lower() != str(root).replace('\\', '/').lower():
        raise ValueError("--repo must refer to the checkout's root directory")
    repo_name = run(root, ["config", "--get", "remote.origin.url"]).lower()
    if "framerudiments" not in repo_name:
        raise ValueError("Not a FrameRudiments checkout")
    try:
        run(root, ["merge-base", "--is-ancestor", BASE_SHA, "HEAD"])
    except subprocess.CalledProcessError as exc:
        raise ValueError(f"This patch requires {BASE_SHA[:12]} on the current branch; pull the annular commit first") from exc

    package = Path(__file__).resolve().parent
    staged = []
    for relative in CHANGED:
        target = root / relative
        if not target.is_file():
            raise ValueError(f"Missing tracked source: {relative}")
        original = target.read_bytes()
        if original.startswith(b'\xef\xbb\xbf'):
            raise ValueError(f"Unsupported UTF-8 BOM in {relative}")
        nl = "\r\n" if b"\r\n" in original else "\n"
        text = original.decode("utf-8").replace("\r\n", "\n")
        updated = change_file(relative, text)
        new = updated.replace("\n", nl).encode("utf-8")
        if new != original:
            staged.append((target, new, relative))
    for relative in ADDED:
        source = package / relative
        target = root / relative
        if not source.is_file():
            raise ValueError(f"Installer package missing {relative}")
        new = source.read_bytes()
        if target.exists() and (not target.is_file() or target.read_bytes() != new):
            raise ValueError(f"Refusing to overwrite an existing different file: {relative}")
        if not target.exists():
            staged.append((target, new, relative))
    if not staged:
        print("Already applied — nothing to change.")
        return
    print(f"Revision: {run(root, ['rev-parse', '--short', 'HEAD'])}")
    for _, blob, relative in staged:
        print(f"  {'would update' if dry_run else 'update'} {relative} [{len(blob)} bytes, sha256 {sha(blob)[:10]}]")
    if dry_run:
        print(f"Verified {len(staged)} file changes. Dry-run only: no files modified.")
        return
    # The check phase has already evaluated every source anchor and new target.
    for target, blob, relative in staged:
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(target.name + ".framerudiments-new")
        if temp.exists():
            raise ValueError(f"Refusing to overwrite temporary file: {temp}")
        try:
            temp.write_bytes(blob)
            temp.replace(target)
        finally:
            if temp.exists():
                temp.unlink()
    print("Applied expansion. Run python -m pytest -q before committing.")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=".")
    parser.add_argument("--check", action="store_true", help="Validate every edit without writing files")
    args = parser.parse_args(argv)
    try:
        install(args.repo, args.check)
    except (OSError, UnicodeError, ValueError, subprocess.CalledProcessError) as exc:
        print(f"FrameRudiments installer: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
