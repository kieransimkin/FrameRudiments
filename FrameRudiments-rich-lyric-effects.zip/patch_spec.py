"""Context-anchored edits for FrameRudiments PR #12 baseline 5e6df9b3.

Never silently skip a modified anchor, replace unrelated source, or overwrite a
new file. No binary assets are needed: indicator glyphs are generated at runtime.
"""
BASE = "5e6df9b3fd9e1df812b49b302beb8aa93261cf59"

EDITS = {
    "src/framerudiments/project.py": [
        ('                      "word_lyrics", "word_captions"}, "project")',
         '                      "word_lyrics", "word_captions", "word_indicator"}, "project")'),
        ('        if "word_captions" in data and not self.word_ref:\n',
         '        if "word_indicator" in data and (not self.word_ref or not self.lyric_ref or not data.get("captions")):\n'
         '            raise ValueError("word_indicator requires lyrics, word_lyrics and full-line captions")\n'
         '        if "word_captions" in data and not self.word_ref:\n'),
    ],
    "src/framerudiments/compositor.py": [
        ('from .word_timing import WordTrack, draw_highlighted_line\n',
         'from .word_timing import WordTrack, draw_highlighted_line\n'
         'from .rich_subtitles import RichTextAppearance\n'
         'from .lyric_indicator import WordIndicator\n'),
        ('                        "completed_colour"}, label)',
         '                        "completed_colour", "font", "effects"}, label)'),
        ('        if not project.font_ref:\n            raise ValueError("Text needs an explicit font")\n'
         '        self.colour = config.get("colour", "#f5eddf")',
         '        self.font_ref = project.ref(config["font"]) if "font" in config else project.font_ref\n'
         '        if not self.font_ref:\n            raise ValueError("Text needs an explicit pinned font")\n'
         '        self.rich = RichTextAppearance(config["effects"]) if "effects" in config else None\n'
         '        self.colour = config.get("colour", "#f5eddf")'),
        ('            font = ImageFont.truetype(self.project.font_ref["path"], size)',
         '            font = ImageFont.truetype(self.font_ref["path"], size)'),
        ('    def draw(self, image, text, *, colour=None):\n'
         '        if not text:\n            return []\n'
         '        font, rows, boxes, height = self.layout(text)',
         '    def draw(self, image, text, *, colour=None):\n'
         '        if not text:\n            return []\n'
         '        if self.rich is not None:\n'
         '            return self.rich.draw(image, self, text, colour=colour)\n'
         '        font, rows, boxes, height = self.layout(text)'),
        ('        self.word_caption = (TextBlock(project, project.data["word_captions"], label="word captions")\n'
         '                             if "word_captions" in project.data else None)\n',
         '        self.word_caption = (TextBlock(project, project.data["word_captions"], label="word captions")\n'
         '                             if "word_captions" in project.data else None)\n'
         '        self.word_indicator = (WordIndicator(project, project.data["word_indicator"], self.context, self.caption)\n'
         '                               if "word_indicator" in project.data else None)\n'),
        ('        if self.word_caption:\n            targets.add("word-caption")\n',
         '        if self.word_caption:\n            targets.add("word-caption")\n'
         '        if self.word_indicator:\n            targets.add("word-indicator")\n'),
        ('        if self.caption.word_mode == "current":\n            return self.caption.draw(image, state["text"])\n'
         '        return draw_highlighted_line(',
         '        if self.caption.word_mode == "current":\n            return self.caption.draw(image, state["text"])\n'
         '        if self.caption.rich is not None:\n'
         '            return self.caption.rich.draw(\n'
         '                image, self.caption, text, active=state["active"],\n'
         '                completed=state["completed"] if self.caption.word_mode == "progressive" else ())\n'
         '        return draw_highlighted_line('),
        ('            if self.word_caption and self.words:\n'
         '                bounds = paint("word-caption", lambda canvas: self._word_caption_draw(canvas, ctx) or None)\n',
         '            if self.word_indicator:\n'
         '                bounds = paint("word-indicator", lambda canvas: self.word_indicator.draw(canvas, ctx))\n'
         '                if bounds:\n'
         '                    text_bounds.append(bounds)\n'
         '            if self.word_caption and self.words:\n'
         '                bounds = paint("word-caption", lambda canvas: self._word_caption_draw(canvas, ctx) or None)\n'),
        ('            if self.word_caption and self.words:\n'
         '                text_bounds.extend(self._word_caption_draw(image, ctx))\n',
         '            if self.word_indicator:\n'
         '                self.word_indicator.draw(image, ctx)\n'
         '            if self.word_caption and self.words:\n'
         '                text_bounds.extend(self._word_caption_draw(image, ctx))\n'),
        ('            if not art_layer:\n                def draw_caption(canvas):\n',
         '            if not art_layer or self.word_indicator:\n                def draw_caption(canvas):\n'),
        ('            if not art_layer:\n                text_bounds.extend(self._caption_draw(image, text, ctx))\n',
         '            if not art_layer or self.word_indicator:\n                text_bounds.extend(self._caption_draw(image, text, ctx))\n'),
        ('    def frame_reports(self):\n'
         '        return {layer.id: layer.frame_report for layer in self.layers\n'
         '                if isinstance(layer, (RudimentLayer, ParticleEmitter)) and layer.frame_report is not None}\n',
         '    def frame_reports(self):\n'
         '        reports = {layer.id: layer.frame_report for layer in self.layers\n'
         '                   if isinstance(layer, (RudimentLayer, ParticleEmitter)) and layer.frame_report is not None}\n'
         '        if self.word_indicator and self.word_indicator.frame_report is not None:\n'
         '            reports["word-indicator"] = self.word_indicator.frame_report\n'
         '        return reports\n'),
        ('                    custom_scene=bool(self.scene),\n',
         '                    custom_scene=bool(self.scene),\n'
         '                    **({"word_indicator": self.word_indicator.evidence} if self.word_indicator else {}),\n'),
    ],
    "tests/test_variable_bpm_words.py": [
        ('    from types import SimpleNamespace\n    from PIL import ImageDraw\n',
         '    from PIL import ImageDraw\n'),
    ],
    ".github/workflows/visualisation-gallery.yml": [
        ('tests/test_particle_engine.py tests/test_variable_bpm_words.py\n',
         'tests/test_particle_engine.py tests/test_variable_bpm_words.py tests/test_rich_subtitles.py\n'),
        ('src/framerudiments/particle_engine.py scripts/generate_particle_gallery.py tests/test_particle_engine.py\n',
         'src/framerudiments/particle_engine.py scripts/generate_particle_gallery.py tests/test_particle_engine.py '
         'src/framerudiments/rich_subtitles.py src/framerudiments/lyric_indicator.py '
         'scripts/generate_rich_lyric_gallery.py tests/test_rich_subtitles.py\n'),
        ('      - name: Generate variable-tempo and word-timing gallery\n'
         '        run: python scripts/generate_timing_gallery.py --output _site\n',
         '      - name: Generate variable-tempo and word-timing gallery\n'
         '        run: python scripts/generate_timing_gallery.py --output _site\n'
         '      - name: Generate rich lyrics and word-indicator gallery\n'
         '        run: python scripts/generate_rich_lyric_gallery.py --output _site\n'),
        ("          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n",
         "          rich = json.loads((p / 'rich-lyrics/catalogue.json').read_text())\n"
         "          assert rich['synthetic'] and len(rich['scenes']) == 8 and len(rich['frames']) == 4\n"
         "          assert (p / 'rich-lyrics/index.html').is_file()\n"
         "          assert len(list((p / 'rich-lyrics').glob('*/*.png'))) == 32\n"
         "          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n"),
    ],
    "README.md": [
        ('## Install and run\n',
         '## Rich lyric typography and word-following particle sprites\n\n'
         'Caption blocks and identity titles optionally accept checksum-pinned `font` overrides and\n'
         '`effects` for stroked, bevelled, embossed, multi-stop gradient, inner/outer glow, and shadowed\n'
         'text. Existing plain text remains untouched unless configured. Set `word_indicator` for a\n'
         'native 1-dimensional DanceRudiment-driven bouncing sprite that tracks the active word of\n'
         'the full line. Its particle field can be continuous, word/cue-triggered, or hybrid;\n'
         'trigger windows independently change colour, density, size, glow and burst count.\n'
         'See [rich lyric reference](docs/rich-lyric-effects.md) and the\n'
         '[CI-generated demo](https://kieransimkin.github.io/FrameRudiments/rich-lyrics/).\n\n'
         '## Install and run\n'),
    ],
    "docs/project-format.md": [
        ('| `font` | Pinned TTF/OTF file for authored text. |',
         '| `font` | Pinned default TTF/OTF for authored text; text blocks may override via their own pinned `font`. |'),
        ('| `lyrics`, `cues` | Separate LRC references; `.cue` files are also supported for structural cues. |',
         '| `lyrics`, `cues` | Separate LRC references; `.cue` files are also supported for structural cues. |\n'
         '| `word_lyrics`, `word_captions`, `word_indicator` | Word LRC source, optional word lane, and word-following sprite/effects. |'),
        ('## Optional full-frame effects\n',
         '## Rich text and word indicator\n\n'
         'Set `effects` and optional checksum-pinned `font` on any `captions`, `word_captions`, or\n'
         '`identity[].style` text block. Rich styles include multi-point gradient fill, stroke, bevel,\n'
         'emboss, inner/outer glow and drop shadow. `word_indicator` needs both line and word LRC,\n'
         'a full-line captions block and a selected native one-axis Rudiment bounce driver. Its\n'
         'particle options support constant emission, timed word/cue bursts and trigger-driven\n'
         'appearance changes; see [full schema and examples](rich-lyric-effects.md).\n\n'
         '## Optional full-frame effects\n'),
    ],
}

NEW_FILES = (
    "src/framerudiments/rich_subtitles.py",
    "src/framerudiments/lyric_indicator.py",
    "scripts/generate_rich_lyric_gallery.py",
    "tests/test_rich_subtitles.py",
    "docs/rich-lyric-effects.md",
)
