# FrameRudiments Rich Lyric Effects — Applying the patch

Source commit: `5e6df9b3fd9e1df812b49b302beb8aa93261cf59` (PR #12 merged).
New components: `rich_subtitles.py`, `lyric_indicator.py`, 28 focused
regression tests and a public synthetic `/rich-lyrics/` Pages demo.

## Recommended: Windows-safe installer

From a **clean** FrameRudiments checkout in PowerShell, with this ZIP downloaded
into that checkout:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/rich-lyric-effects

$pkg = Join-Path $env:TEMP 'FrameRudimentsRichLyrics'
Expand-Archive .\FrameRudiments-rich-lyric-effects.zip -DestinationPath $pkg -Force

py "$pkg\apply_rich_lyric_effects.py" --repo . --check
py "$pkg\apply_rich_lyric_effects.py" --repo .
```

The `--check` step verifies all targets and all new-file conflicts without
writing. The installer requires the exact unmodified baseline commit and
allows a no-op repeat application while still on that uncommitted branch.
It handles CRLF text files and never overwrites conflicting file contents.
If it rejects the checkout, send the error and `git rev-parse HEAD` — don't
force a three-way merge over local edits.

If you explicitly prefer the enclosed unified diff, note that it contains
zero-context single-line hunks and **requires** `--unidiff-zero`. Use it only
with a clean checkout of the exact commit and dry-run first:

```powershell
git apply --unidiff-zero --check "$pkg\FrameRudiments-rich-lyric-effects.patch"
git apply --unidiff-zero "$pkg\FrameRudiments-rich-lyric-effects.patch"
```

Do **not** run the installer after a successful `git apply`, or vice versa.

## Regression and integration checks

```powershell
python -m pip install -e ".[dev]"
python -m pytest -q tests/test_rich_subtitles.py tests/test_variable_bpm_words.py tests/test_lyrics.py
ruff check .
git diff --check
python -m build
```

The GitHub Pages workflow also runs the full gallery generator, including
`python scripts/generate_rich_lyric_gallery.py --output _site`, after producing
`_site/index.html`; it validates 8 scenes and 32 synthetic PNG previews.

Once CI passes on the feature branch, open a PR, merge to `main`, and verify
that both repository CI and the Pages workflow finish successfully before
claiming the public page is live:

https://kieransimkin.github.io/FrameRudiments/rich-lyrics/

## Compatibility

The new `word_indicator` is opt-in and requires `lyrics`, `word_lyrics`, and
`captions`. It uses native DanceRudiments for the scalar bounce axis, and word/
cue events remain tied to the source audio's timing ledger. Existing plain text
and font rendering are unchanged if per-block `effects`, `font`, and
`word_indicator` are absent. No private fonts/audio are bundled in this patch.

## Existing CI issue included

The previous merged PR #12 introduced one unrelated Ruff `F401` issue:
`tests/test_variable_bpm_words.py` imported `SimpleNamespace` without using it.
This package removes that single import so new CI runs can progress. The last
observed CI runs were **failing**, and successful native integration and Pages
deployment still need to be verified after applying this patch.
