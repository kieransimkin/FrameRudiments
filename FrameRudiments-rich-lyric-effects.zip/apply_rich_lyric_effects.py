"""Windows-safe, conflict-checking installer for FrameRudiments rich lyric effects.

Run --check first, then rerun without --check to commit exactly the same edit
plan. This never mutates .git, never replaces a nonmatching file, never
changes arbitrary asset paths, and is safe to rerun after successful install.
"""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys

from patch_spec import BASE, EDITS, NEW_FILES


def _bytes(path):
    return path.read_bytes()


def _read(path):
    original = _bytes(path)
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    raw = original[len(bom):]
    text = raw.decode("utf-8")
    newline = "\r\n" if b"\r\n" in raw else "\n"
    return text.replace("\r\n", "\n"), bom, newline, original


def _plan(repo, *, head_check=True):
    base = Path(__file__).resolve().parent
    if head_check:
        result = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo,
                                capture_output=True, text=True, check=True)
        head = result.stdout.strip()
        if head != BASE:
            raise ValueError(f"Repository HEAD is {head}; this package targets {BASE}. "
                             "Update the patch baseline before installing onto a different commit.")
    operations = {}
    for relative, changes in EDITS.items():
        dest = repo / relative
        if not dest.is_file():
            raise ValueError(f"Required source file is missing: {relative}")
        text, bom, newline, original = _read(dest)
        updated = text
        for old, new in changes:
            if old in new and updated.count(new) == 1:
                # A previous successful edit may retain the original anchor.
                continue
            if updated.count(old) == 1:
                updated = updated.replace(old, new, 1)
            elif updated.count(new) == 1:
                continue
            else:
                raise ValueError(f"Conflict applying {relative}: missing/ambiguous source context: {old[:95]!r}")
        outgoing = bom + updated.replace("\n", newline).encode("utf-8")
        if outgoing != original:
            operations[dest] = outgoing
    for relative in NEW_FILES:
        dest = repo / relative
        source = base / relative
        contents = _bytes(source)
        if dest.exists():
            if not dest.is_file() or _bytes(dest) != contents:
                raise ValueError(f"New file path already occupied with different bytes: {relative}")
        else:
            operations[dest] = contents
    return operations


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    repo = args.repo.resolve()
    try:
        operations = _plan(repo)
        print(f"Patch target {BASE[:12]} · {len(EDITS)} modified source files · "
              f"{len(NEW_FILES)} new source/docs/tests · {len(operations)} changes pending")
        for path, contents in operations.items():
            print(f"{'WOULD WRITE' if args.check else 'WRITE'} {path.relative_to(repo)} "
                  f"({len(contents):,} bytes, SHA-256 {hashlib.sha256(contents).hexdigest()[:12]})")
        if args.check or not operations:
            return 0
        # All conflicts have already been checked. Write to temporary files on
        # the destination filesystem then replace, never partly truncate text.
        for path, contents in operations.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(path.name + ".rich-lyric-tmp")
            if tmp.exists():
                raise ValueError(f"Unexpected installer staging path: {tmp}")
            try:
                tmp.write_bytes(contents)
                tmp.replace(path)
            finally:
                tmp.unlink(missing_ok=True)
        print("Rich lyric effects installed; run pytest, Ruff and the full CI before merging.")
        return 0
    except (ValueError, OSError, UnicodeError, subprocess.CalledProcessError) as exc:
        print(f"Cannot apply rich lyric effects: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
