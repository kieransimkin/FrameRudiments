"""Source-preserving insertion rules for commit 5656afb6 of FrameRudiments."""
BASE = '5656afb613526c1f01913762be671bb5baf450ae'

INTRO = '''## Particle and smoke emitters

A new deterministic `type: "emitter"` layer provides continuous smoke,
sparks, embers, snow, rain, confetti and cue-triggered bursts, driven by
independent DanceRudiments. Pinned DanceMoves/StemLab `.lrc`, `.cue`, or
versioned `.json` timing files can trigger one-shot explosions; `hybrid`
mode combines these with constant emission. Every parameter in the engine's
numeric style table supports native `style.*` modulation. Pinned transparent
PNG particles are optional, and the existing element- and frame-level post
passes remain available. See [particle and smoke reference](docs/particle-smoke.md)
and the [CI-generated synthetic gallery](https://kieransimkin.github.io/FrameRudiments/particles/).

'''
PROJECT_DOC = '''## Particle and smoke emitters

`layers` may include `{ "type": "emitter", "id": "haze", "kind": "smoke", ... }`.
Emission modes are `continuous`, `cue` and `hybrid`. Cue `.lrc` files use
DanceMoves/StemLab source-time labels; `.json` accepts DanceMoves cue objects
or StemLab cue-snap/cue-generate reports. Optional custom particle PNGs and cue
files must use ordinary `{path, sha256}` file references. Independent native
DanceRudiment modulators can target validated numeric `style.*` or `visual.*`
settings. See [particle and smoke](particle-smoke.md) for the full schema,
selection patterns, repeat/excerpt behaviour and safety limits.

'''
RENDERER_DOC = '''## Emitter layers alongside visualisers

`type: "emitter"` adds smoke, sparks, rain, snow, confetti or other particles
as a separate alpha-composited layer, not a replacement for any vector or
sprite Rudiment renderer. The same scoped post-effects target syntax
`layer:<id>` applies to emitters. Continuous and source-cue-triggered modes,
custom pinned sprite tiles and native DanceRudiment parameter modulation are
documented in [particle-smoke.md](particle-smoke.md).

'''
MODS = {
    'src/framerudiments/compositor.py': [
        (10,
         'from .rudiment_renderers import RudimentLayer, default_renderers\nfrom .motion import Motion\n',
         'from .rudiment_renderers import RudimentLayer, default_renderers\nfrom .particle_engine import ParticleEmitter\nfrom .motion import Motion\n'),
        (209,
         '        self.layers = [RudimentLayer(project, cfg, self.renderers, self.context)\n'
         '                       if cfg.get("type") == "rudiment" else Sprite(project, cfg)\n'
         '                       for cfg in project.data.get("layers", [])]\n',
         '        self.layers = [\n'
         '            RudimentLayer(project, cfg, self.renderers, self.context)\n'
         '            if cfg.get("type") == "rudiment" else\n'
         '            ParticleEmitter(project, cfg, self.context)\n'
         '            if cfg.get("type") == "emitter" else Sprite(project, cfg)\n'
         '            for cfg in project.data.get("layers", [])\n'
         '        ]\n'),
        (369,
         '        return {layer.id: layer.frame_report for layer in self.layers\n'
         '                if isinstance(layer, RudimentLayer) and layer.frame_report is not None}\n',
         '        return {layer.id: layer.frame_report for layer in self.layers\n'
         '                if isinstance(layer, (RudimentLayer, ParticleEmitter)) and layer.frame_report is not None}\n'),
        (378,
         '                    rudiment_renderers={x.id: x.evidence for x in self.layers if isinstance(x, RudimentLayer)},\n'
         '                    custom_scene=bool(self.scene),\n',
         '                    rudiment_renderers={x.id: x.evidence for x in self.layers if isinstance(x, RudimentLayer)},\n'
         '                    **({"emitters": {x.id: x.evidence for x in self.layers\n'
         '                       if isinstance(x, ParticleEmitter)}} if any(isinstance(x, ParticleEmitter)\n'
         '                       for x in self.layers) else {}),\n'
         '                    custom_scene=bool(self.scene),\n'),
    ],
    '.github/workflows/visualisation-gallery.yml': [
        (32,
         '        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py tests/test_quality_effects.py\n',
         '        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py tests/test_quality_effects.py tests/test_particle_engine.py\n'),
        (34,
         '        run: ruff check scripts/generate_visualisation_gallery.py src/framerudiments/advanced_renderers.py src/framerudiments/circular_renderers.py src/framerudiments/visualisation_catalogue.py src/framerudiments/visual_style.py src/framerudiments/modulation.py src/framerudiments/effect_catalogue.py src/framerudiments/effect_renderers.py src/framerudiments/post_effects.py src/framerudiments/scoped_effects.py scripts/generate_post_effect_gallery.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py src/framerudiments/sprite_renderers.py src/framerudiments/sprite_catalogue.py scripts/generate_sprite_gallery.py scripts/build_sprite_assets.py src/framerudiments/quality_effects.py scripts/generate_quality_gallery.py tests/test_quality_effects.py\n',
         '        run: ruff check scripts/generate_visualisation_gallery.py src/framerudiments/advanced_renderers.py src/framerudiments/circular_renderers.py src/framerudiments/visualisation_catalogue.py src/framerudiments/visual_style.py src/framerudiments/modulation.py src/framerudiments/effect_catalogue.py src/framerudiments/effect_renderers.py src/framerudiments/post_effects.py src/framerudiments/scoped_effects.py scripts/generate_post_effect_gallery.py tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py src/framerudiments/sprite_renderers.py src/framerudiments/sprite_catalogue.py scripts/generate_sprite_gallery.py scripts/build_sprite_assets.py src/framerudiments/quality_effects.py scripts/generate_quality_gallery.py tests/test_quality_effects.py src/framerudiments/particle_engine.py scripts/generate_particle_gallery.py tests/test_particle_engine.py\n'),
        (41,
         '      - name: Generate sprite and vector comparison gallery\n'
         '        run: python scripts/generate_sprite_gallery.py --output _site\n',
         '      - name: Generate sprite and vector comparison gallery\n'
         '        run: python scripts/generate_sprite_gallery.py --output _site\n'
         '      - name: Generate particles and smoke gallery\n'
         '        run: python scripts/generate_particle_gallery.py --output _site\n'),
        (67,
         "          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n",
         "          particles = json.loads((p / 'particles/catalogue.json').read_text())\n"
         "          assert particles['synthetic'] and not particles['measured_audio']\n"
         "          assert len(particles['scenes']) == 12 and len(particles['frames']) == 4\n"
         "          assert (p / 'particles/index.html').is_file()\n"
         "          assert len(list((p / 'particles').glob('*/*.png'))) == 48\n"
         "          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n"),
    ],
    'README.md': [
        (26, '## Install and run\n', INTRO + '## Install and run\n'),
    ],
    'docs/project-format.md': [
        (116, '## Optional full-frame effects\n', PROJECT_DOC + '## Optional full-frame effects\n'),
    ],
    'docs/rudiment-renderers.md': [
        (142, '## Calibrated Fourier spectrum\n', RENDERER_DOC + '## Calibrated Fourier spectrum\n'),
    ],
}

NEW = (
    'src/framerudiments/particle_engine.py',
    'tests/test_particle_engine.py',
    'scripts/generate_particle_gallery.py',
    'docs/particle-smoke.md',
)

# Adjacent CI assertions share a context line. Combine the two edits into
# one non-overlapping Git hunk instead of producing conflicting hunks.
_workflow = '.github/workflows/visualisation-gallery.yml'
_p = MODS[_workflow]
MODS[_workflow] = [(
    31,
    '      - name: Validate all visualisation modes and deterministic output\n'
    + _p[0][1]
    + '      - name: Lint gallery and renderer implementation\n'
    + _p[1][1],
    '      - name: Validate all visualisation modes and deterministic output\n'
    + _p[0][2]
    + '      - name: Lint gallery and renderer implementation\n'
    + _p[1][2],
), *_p[2:]]
