"""Windows-safe, baseline-aware installer for FrameRudiments particle emitters."""
import argparse
from pathlib import Path
import subprocess
import sys

from patch_spec import BASE, MODS, NEW


def apply(repo, package, *, check):
    repo = Path(repo).resolve()
    if not (repo / '.git').exists() or not (repo / 'src/framerudiments/compositor.py').is_file():
        raise ValueError('Run from a FrameRudiments Git checkout (or pass --repo)')
    head = subprocess.run(['git', '-C', str(repo), 'rev-parse', 'HEAD'],
                          check=True, capture_output=True, text=True).stdout.strip()
    if head != BASE:
        print(f'Warning: patch prepared for main {BASE[:12]}, local HEAD {head[:12]}; '
              'individual source anchors will be checked strictly.')
    updates = {}
    for target, operations in MODS.items():
        source = repo / target
        raw = source.read_bytes()
        newline = '\r\n' if b'\r\n' in raw else '\n'
        text = raw.decode('utf-8-sig').replace('\r\n', '\n')
        before = text
        for _, old, new in operations:
            count = text.count(old)
            if count == 1:
                text = text.replace(old, new)
            elif count == 0 and new in text:
                pass  # idempotent, already installed
            else:
                raise ValueError(f'{target}: could not uniquely match patch context; '
                                 'local edits need review; nothing was written')
        if text != before:
            updates[target] = text.replace('\n', newline).encode('utf-8')
    for target in NEW:
        source = package / target
        original = repo / target
        content = source.read_bytes()
        if original.exists():
            if original.read_bytes() != content:
                raise ValueError(f'{target}: existing file differs; refusing overwrite')
        else:
            updates[target] = content
    print(f'Checked {len(MODS)} existing paths, {len(NEW)} new paths; '
          f'{len(updates)} file(s) need writing.')
    if check:
        print('Dry-run complete; no files changed.')
        return
    for path, data in updates.items():
        out = repo / path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        print('Applied', path)
    print('Patch applied. Run pytest and ruff before committing.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default='.')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    try:
        apply(args.repo, Path(__file__).resolve().parent, check=args.check)
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        print(f'FrameRudiments emitter patch: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
