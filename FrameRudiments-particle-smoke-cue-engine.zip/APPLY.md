# FrameRudiments particle/smoke expansion

Target base: `5656afb613526c1f01913762be671bb5baf450ae` (merge PR #10).
The installer **does not overwrite mismatched existing files**. Use a clean
feature branch and keep prior work committed. From PowerShell:

```powershell
git switch main
git pull --ff-only origin main
git switch -c feature/particle-smoke-cue-engine

$pkg = Join-Path $env:TEMP 'FrameRudimentsParticles'
Expand-Archive .\FrameRudiments-particle-smoke.zip -DestinationPath $pkg -Force
py "$pkg\apply_particle_engine.py" --repo . --check
py "$pkg\apply_particle_engine.py" --repo .

python -m pip install -e '.[dev]'
python -m pytest -q tests/test_particle_engine.py
ruff check .
git diff --check
```

Alternatively, apply `FrameRudiments-particle-smoke.patch` with `git apply --check`
first, then `git apply`, **not both installer and patch**. The patch includes
new files, documentation and gallery workflow integration. It is based on the
exact `main` listed above; when other changes have landed, run the installer
in dry-run mode to detect conflicts before touching anything.

The GitHub Pages workflow builds a 12-scene synthetic emitter gallery at
`https://kieransimkin.github.io/FrameRudiments/particles/` after merge,
assuming Pages deployment is enabled. The site is not live until CI deploys.

The local smoke harness in the development bundle is not part of the uploaded
production source. It cannot substitute for full Windows/Linux native CI.
