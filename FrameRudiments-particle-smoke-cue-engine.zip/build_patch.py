"""Build a normal Git patch with real-line-number hunks and genuine source context."""
import difflib
from pathlib import Path
import re

from patch_spec import MODS, NEW

ROOT = Path(__file__).resolve().parent
# Original repo line indexes and adjacent source, checked against main HEAD.
CONTEXT = {
    'src/framerudiments/compositor.py': [
        ('', ''),
        ('        self.renderers = default_renderers() if renderers is None else renderers\n',
         '        ids = [x.id for x in self.layers]\n'),
        ('    def frame_reports(self):\n', '\n    def post_effect_reports(self):\n'),
        ('', ''),
    ],
    '.github/workflows/visualisation-gallery.yml': [
        ("        run: python -m pip install -e '.[dev]'\n",
         '      - name: Render complete gallery from synthetic display fixtures\n'),
        ('', '      - name: Validate generated site and image count\n'),
        ("          assert (p / 'quality' / scene['name'] / f'{j}.png').is_file()\n",
         "          assert sprites['sprite_renderer_count'] == 52 and sprites['themes'] == 17\n"),
    ],
    'README.md': [('', '\nPython 3.11+ and FFmpeg with libx264/AAC are required. Install the package into\n')],
    'docs/project-format.md': [('', '\nThe top-level `effects` list is additive to v1. See [visualisers.md](visualisers.md)\n')],
    'docs/rudiment-renderers.md': [('', '\nThe `spectrum` renderer adds actual StemLab band levels, frequency labels,\n')],
}


def lines(text):
    return text.splitlines(keepends=True)


def patch_hunk(first_line, before, after, delta):
    old, new = list(lines(before)), list(lines(after))
    diff = list(difflib.unified_diff(old, new, n=1, lineterm=''))
    if len(diff) < 3:
        raise ValueError('Empty or malformed source hunk')
    body = diff[2:]
    result = []
    for row in body:
        if row.startswith('@@ '):
            m = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', row)
            if not m:
                raise ValueError('Malformed hunk')
            old_at = int(m[1]) + first_line - 1
            new_at = int(m[3]) + first_line - 1 + delta
            a = ',' + m[2] if m[2] is not None else ''
            b = ',' + m[4] if m[4] is not None else ''
            result.append(f'@@ -{old_at}{a} +{new_at}{b} @@\n')
        else:
            result.append(row + ('\n' if not row.endswith('\n') else ''))
    return ''.join(result)


def build():
    output = []
    for path, entries in MODS.items():
        output.append(f'diff --git a/{path} b/{path}\n')
        output.append(f'--- a/{path}\n+++ b/{path}\n')
        total_delta = 0
        for (line, old, new), (prefix, suffix) in zip(entries, CONTEXT[path]):
            first = line - prefix.count('\n')
            output.append(patch_hunk(first, prefix + old + suffix, prefix + new + suffix, total_delta))
            total_delta += new.count('\n') - old.count('\n')
    for path in NEW:
        source = ROOT / path
        content = source.read_text(encoding='utf-8')
        payload = lines(content)
        output.append(f'diff --git a/{path} b/{path}\nnew file mode 100644\n'
                      f'--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(payload)} @@\n')
        output.extend('+' + row for row in payload)
    dest = ROOT / 'FrameRudiments-particle-smoke.patch'
    dest.write_text(''.join(output), encoding='utf-8')
    print('Built:', dest, 'bytes:', dest.stat().st_size)


if __name__ == '__main__':
    build()
