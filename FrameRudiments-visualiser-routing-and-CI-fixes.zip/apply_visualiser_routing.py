"""Safely install FrameRudiments layer feed/overlay routing and CI corrections.

All paths and existing text are verified before any file is written. Supports
CRLF working copies, rerunning after a successful apply and unrelated edits.
Does not create branches, publish releases, or modify existing Git metadata.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import sys

from patch_spec import BASE, EDITS, NEW_FILES


def _read_text(path):
    data = path.read_bytes()
    bom = b"\xef\xbb\xbf" if data.startswith(b"\xef\xbb\xbf") else b""
    rest = data[len(bom):]
    newline = "\r\n" if b"\r\n" in rest else "\n"
    return rest.decode("utf-8").replace("\r\n", "\n"), bom, newline, data


def _plan(repo):
    proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True, text=True, check=True)
    head = proc.stdout.strip()
    if head != BASE:
        raise ValueError(f"Expected FrameRudiments baseline {BASE}; found {head}. "
                         "Use the branch created from the specified main revision.")
    root = Path(__file__).resolve().parent
    edits = {}
    for path, patches in EDITS.items():
        target = repo / path
        if not target.is_file() or not target.resolve().is_relative_to(repo):
            raise ValueError(f"Missing or unsafe existing path: {path}")
        content, bom, newline, original = _read_text(target)
        for replacement in patches:
            old, new = replacement[:2]
            expected = replacement[2] if len(replacement) >= 3 else 1
            if old == new:
                continue
            if content.count(new) == expected:
                continue  # already applied
            if content.count(old) != expected:
                raise ValueError(f"Conflict at {path}: expected {expected} instance(s) of {old[:65]!r}; "
                                 f"found {content.count(old)}")
            content = content.replace(old, new, expected)
        result = bom + content.replace("\n", newline).encode("utf-8")
        if result != original:
            edits[target] = result
    for path in NEW_FILES:
        source, target = root / path, repo / path
        if not source.is_file():
            raise ValueError(f"Missing package file: {path}")
        data = source.read_bytes()
        if target.exists():
            if not target.is_file() or not target.resolve().is_relative_to(repo) or target.read_bytes() != data:
                raise ValueError(f"Existing new-file conflict: {path}")
        else:
            if not target.parent.resolve().is_relative_to(repo):
                raise ValueError(f"Unsafe destination directory: {path}")
            edits[target] = data
    # Avoid stale private temporary destinations before the first write.
    for target in edits:
        temp = target.with_name(target.name + ".visualiser-route-tmp")
        if temp.exists():
            raise ValueError(f"Unexpected temporary path exists: {temp}")
    return edits


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--check", action="store_true", help="Inspect all planned writes but change nothing")
    args = parser.parse_args(argv)
    repo = args.repo.resolve()
    try:
        changes = _plan(repo)
        for target, data in changes.items():
            print(f"{'CHECK' if args.check else 'APPLY'} {target.relative_to(repo)} "
                  f"({len(data):,} bytes, SHA-256 {hashlib.sha256(data).hexdigest()[:12]})")
        if args.check:
            print(f"Validation successful: {len(changes)} files pending; nothing modified.")
            return 0
        for target, data in changes.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_name(target.name + ".visualiser-route-tmp")
            try:
                with temp.open("xb") as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                temp.replace(target)
            finally:
                temp.unlink(missing_ok=True)
        print("Visualiser routing and CI corrections installed; run tests before committing.")
        return 0
    except (ValueError, OSError, UnicodeError, subprocess.CalledProcessError) as exc:
        print(f"Cannot apply visualiser routing patch: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
