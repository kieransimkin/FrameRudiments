# FrameRudiments — layer-selective Butterchurn/projectM input routing

**Target:** `main` commit `3a8f417284965eca5ba87df2880d2b09ec00ea7a`.

This expansion adds optional `visualiser_routing` configuration with independent
`feed: continuous | never | {mode: first_pips, duration_pips: N}` and
`overlay: true | false` policies per isolated layer. A feed window starts at
actual first visibility and can rearm on visibility, lyric or cue changes.
Pips follow the 64-pip source clock (including StemLab/DanceMoves variable BPM).
The original no-routing composition remains untouched.

## Install from PowerShell

Save `FrameRudiments-visualiser-routing-and-CI-fixes.zip` in your FrameRudiments
checkout and check you have no unexpected local changes. Then:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/visualiser-layer-routing

$pkg = Join-Path $env:TEMP 'FrameRudimentsRouting'
Expand-Archive .\FrameRudiments-visualiser-routing-and-CI-fixes.zip -DestinationPath $pkg -Force

py "$pkg\apply_visualiser_routing.py" --repo . --check
if ($LASTEXITCODE -ne 0) { throw 'Installer dry-run failed. No files have changed.' }
py "$pkg\apply_visualiser_routing.py" --repo .
if ($LASTEXITCODE -ne 0) { throw 'Installer failed.' }

python -m pip install -e '.[dev]'
ruff check .
python -m pytest -q tests/test_visualiser_routing.py tests/test_supersampling.py tests/test_visualisers.py tests/test_rudiment_renderers.py tests/test_pipeline.py
git diff --check
```

If local tests are green, commit and push the branch. CI will generate a
synthetic `/routing/` gallery with **12 scenarios × five moments = 60 PNGs**,
plus machine-checkable per-layer reports. The GPU acceptance suite continues
testing actual Butterchurn/projectM runtimes separately. The gallery clearly
labels its illustrative feedback simulation; it is not a GPU screenshot.

## CI fixes included

- Keep trusted custom scene-hook calls at once per **encoded** frame during
  high-FPS supersampling; do not advance a stateful scene hook eight times.
- Opt legacy exact-pixel tests out of the newly default 4× spatial/8× temporal
  supersampling, without lowering quality for production projects.
- Restore the original `viewport-sized RGBA` error contract for bad plugins.

## Validation and risks

The installer refuses a different baseline and conflicting files; it preserves
unrelated local changes, UTF-8 BOM and CRLF. This distribution contains no
private media, external presets or runtime downloads. Its new routing unit tests
were checked locally, and the generator produced the expected 60 images.
**Full native repo CI and real GPU alpha-feedback tests remain unverified until
this branch is pushed**. In particular, retain a manual QA checkpoint before
shipping a GPU-backed production video.

The projectM and Butterchurn host bridges now respect transparent input pixels.
The projectM portrait padding is transparent for routed inputs, but stays black
for existing all-opaque content. Routing itself processes each encoded frame in
sequential order, like the underlying GPU feedback engine.
