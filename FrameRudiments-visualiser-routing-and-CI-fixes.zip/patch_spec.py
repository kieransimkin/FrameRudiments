"""Exact-context source changes against FrameRudiments 3a8f4172."""
BASE = "3a8f417284965eca5ba87df2880d2b09ec00ea7a"
EDITS = {
"src/framerudiments/project.py": [
('"word_lyrics", "word_captions", "word_indicator", "render_quality"}, "project")',
 '"word_lyrics", "word_captions", "word_indicator", "render_quality", "visualiser_routing"}, "project")'),
('                    render_quality=self.output_quality.evidence, inputs=self.inputs,',
 '                    render_quality=self.output_quality.evidence,\n'
 '                    **({"visualiser_routing": self.data["visualiser_routing"]}\n'
 '                       if "visualiser_routing" in self.data else {}), inputs=self.inputs,'),
],
"src/framerudiments/compositor.py": [
('from .scoped_effects import CompositingEffects\n',
 'from .scoped_effects import CompositingEffects\n'
 'from .visualiser_routing import VisualiserLayerRouting\n'),
('        self.post_pipeline = CompositingEffects(project, project.data.get("post_effects", {}),\n'
 '                                                self.context, valid_elements=targets)',
 '        self.post_pipeline = CompositingEffects(project, project.data.get("post_effects", {}),\n'
 '                                                self.context, valid_elements=targets)\n'
 '        self.visualiser_routing = None\n'
 '        if "visualiser_routing" in project.data:\n'
 '            if not self.effect_specs:\n'
 '                raise ValueError("visualiser_routing needs at least one Butterchurn/projectM effect")\n'
 '            # Match the established draw order; the lyric artwork/caption branch\n'
 '            # determines which one is actually visible at each frame.\n'
 '            element_order = ["background"]\n'
 '            if self.scene:\n'
 '                element_order.append("scene")\n'
 '            element_order.extend(f"layer:{layer.id}" for layer in self.layers)\n'
 '            element_order.extend(f"identity:{index}" for index in range(len(self.identity)))\n'
 '            element_order.extend(f"lyric-art:{layer.id.rsplit(\'-\', 1)[-1]}"\n'
 '                                 for layer in self.lyric_art.values())\n'
 '            if self.caption:\n'
 '                element_order.append("caption")\n'
 '            if self.word_indicator:\n'
 '                element_order.append("word-indicator")\n'
 '            if self.word_caption:\n'
 '                element_order.append("word-caption")\n'
 '            self.visualiser_routing = VisualiserLayerRouting(\n'
 '                project.data["visualiser_routing"], element_order, self.background.size)\n'
 '        self._route_parts = []'),
('        pipeline.begin()\n        image = pipeline.apply_element(self.background.copy(), "background", ctx)\n',
 '        pipeline.begin()\n'
 '        self._route_parts = []\n'
 '        background = pipeline.apply_element(self.background.copy(), "background", ctx)\n'
 '        self._capture_route("background", background)\n'
 '        image = background\n'),
('            if pipeline.affects("scene"):\n',
 '            if pipeline.affects("scene") or self.visualiser_routing is not None:\n'),
('                image.alpha_composite(pipeline.apply_element(scene_ink, "scene", ctx))',
 '                scene_ink = pipeline.apply_element(scene_ink, "scene", ctx)\n'
 '                self._capture_route("scene", scene_ink)\n'
 '                image.alpha_composite(scene_ink)'),
('            actual = scratch.getchannel("A").getbbox()\n            image.alpha_composite(scratch)',
 '            actual = scratch.getchannel("A").getbbox()\n'
 '            self._capture_route(key, scratch)\n'
 '            image.alpha_composite(scratch)'),
('    def _frame_with_post_effects(self, ctx):\n',
 '    def _capture_route(self, name, image):\n'
 '        if self.visualiser_routing is not None:\n'
 '            self._route_parts.append((name, image.copy()))\n\n'
 '    def _frame_with_post_effects(self, ctx):\n'),
('        if self.post_pipeline.enabled:\n            # Final-frame opacity/rotation',
 '        if self.post_pipeline.enabled or self.visualiser_routing is not None:\n'
 '            # Final-frame opacity/rotation'),
('                    custom_scene=bool(self.scene),\n',
 '                    custom_scene=bool(self.scene),\n'
 '                    **({"visualiser_routing": self.visualiser_routing.evidence}\n'
 '                       if self.visualiser_routing is not None else {}),\n'),
],
"src/framerudiments/visualisers.py": [
('    def __init__(self, project, specs, ffmpeg, output, *, factories=None):',
 '    def __init__(self, project, specs, ffmpeg, output, *, factories=None, routing=None):'),
('        self.specs = specs\n', '        self.specs = specs\n        self.routing = routing\n'),
('    def process(self, image, context):\n        if context.frame != self.next_frame:\n            raise ValueError("MilkDrop feedback requires sequential frames from zero; recreate and replay to seek")\n        pcm = self.audio.at(context.frame)',
 '    def process(self, image, context, *, isolated_layers=None):\n'
 '        if context.frame != self.next_frame:\n'
 '            raise ValueError("MilkDrop feedback requires sequential frames from zero; recreate and replay to seek")\n'
 '        overlay = None\n'
 '        if self.routing is not None:\n'
 '            if isolated_layers is None:\n'
 '                raise ValueError("Routed visualisers require the isolated compositor surfaces")\n'
 '            image, overlay = self.routing.route(context, isolated_layers)\n'
 '        pcm = self.audio.at(context.frame)'),
('        self.next_frame += 1\n        return image.convert("RGB")',
 '        self.next_frame += 1\n'
 '        if overlay is not None:\n'
 '            final = image.convert("RGBA")\n'
 '            final.alpha_composite(overlay)\n'
 '            image = final\n'
 '        return image.convert("RGB")'),
('                    sequential_frames=self.next_frame, pcm=self.audio.evidence,',
 '                    sequential_frames=self.next_frame, pcm=self.audio.evidence,\n'
 '                    routing=self.routing.evidence if self.routing is not None else None,'),
],
"src/framerudiments/projectm_backend.py": [
('        # Uniform source contribution preserves previous processed pixels in feedback.\n'
 '        frame.putalpha(round(self.mix * 255))',
 '        # Preserve source alpha so an unfed layer cannot paint black into feedback.\n'
 '        # Fully opaque legacy inputs remain numerically unchanged.\n'
 '        frame.putalpha(frame.getchannel("A").point(lambda a: round(a * self.mix)))'),
],
"src/framerudiments/visualiser_assets/butterchurn-page.js": [
('out vec4 colour; void main(){ colour=vec4(texture(source,uv).rgb,amount); }',
 'out vec4 colour; void main(){ vec4 pixel=texture(source,uv); colour=vec4(pixel.rgb,pixel.a*amount); }'),
],
"src/framerudiments/render.py": [
('EffectChain(p, compositor.effect_specs, ffmpeg, out) if compositor.effect_specs else None',
 'EffectChain(p, compositor.effect_specs, ffmpeg, out,\n'
 '                              routing=compositor.visualiser_routing) if compositor.effect_specs else None', 2),
('                    image = effects.process(image, context)\n',
 '                    image = effects.process(\n'
 '                        image, context, isolated_layers=compositor._route_parts\n'
 '                        if compositor.visualiser_routing is not None else None)\n',2),
('    post = compositor.post_effect_reports()\n    if reports or post:',
 '    post = compositor.post_effect_reports()\n'
 '    routed = (compositor.visualiser_routing.last_report\n'
 '              if compositor.visualiser_routing is not None else None)\n'
 '    if reports or post or routed:'),
('        if post:\n            entry["post_effects"] = post\n        handle.write',
 '        if post:\n            entry["post_effects"] = post\n'
 '        if routed:\n            entry["visualiser_routing"] = routed\n        handle.write'),
],
"src/framerudiments/super_sampling.py": [
('            from dataclasses import replace\n\n            def scene_adapter(image, context):\n                return scene(image, replace(context, frame=context.frame // factor))',
 '            from dataclasses import replace\n'
 '            scene_cache = {"frame": None, "pixels": None}\n\n'
 '            def scene_adapter(image, context):\n'
 '                encoded = context.frame // factor\n'
 '                if scene_cache["frame"] != encoded:\n'
 '                    # Trusted scene hooks own encoded frames, not high-FPS samples.\n'
 '                    # Never invoke a stateful hook eight times for one output frame.\n'
 '                    scene_cache["pixels"] = scene(image, replace(context, frame=encoded)).copy()\n'
 '                    scene_cache["frame"] = encoded\n'
 '                return scene_cache["pixels"].copy()'),
('    images = []\n    for j in range(factor):\n        sample, _ = virtual.frame(min(frame * factor + j, virtual.project.frame_count - 1),\n                                  apply_quality=False)\n        images.append(sample)',
 '    images = []\n'
 '    route_averages = {}\n'
 '    route_keys = (compositor.visualiser_routing.available\n'
 '                  if getattr(compositor, "visualiser_routing", None) is not None else ())\n'
 '    for j in range(factor):\n'
 '        sample, _ = virtual.frame(min(frame * factor + j, virtual.project.frame_count - 1),\n'
 '                                  apply_quality=False)\n'
 '        images.append(sample)\n'
 '        if route_keys:\n'
 '            parts = dict(virtual._route_parts)\n'
 '            for key in route_keys:\n'
 '                value = parts.get(key)\n'
 '                if value is None:\n'
 '                    value = Image.new("RGBA", sample.size)\n'
 '                value = value.convert("RGBa")\n'
 '                route_averages[key] = (value if j == 0 else\n'
 '                    Image.blend(route_averages[key], value, 1 / (j + 1)))\n'
 '    if route_keys:\n'
 '        compositor._route_parts = [(key, route_averages[key].convert("RGBA"))\n'
 '                                   for key in route_keys]'),
('raise ValueError("Supersampled vector must render a full-size RGBA viewport")',
 'raise ValueError("Supersampled vector must return viewport-sized RGBA image")'),
],
"tests/test_rudiment_renderers.py": [
('    compositor = Compositor(project, renderers=registry)\n    image, _ = compositor.frame(30)',
 '    from framerudiments.output_quality import OutputQuality\n'
 '    project.output_quality = OutputQuality({"enabled": False})\n'
 '    compositor = Compositor(project, renderers=registry)\n    image, _ = compositor.frame(30)'),
('    with pytest.raises(ValueError, match="viewport-sized RGBA"):\n        Compositor(project, renderers=registry).frame(0)',
 '    from framerudiments.output_quality import OutputQuality\n'
 '    project.output_quality = OutputQuality({"enabled": False})\n'
 '    with pytest.raises(ValueError, match="viewport-sized RGBA"):\n'
 '        Compositor(project, renderers=registry).frame(0)'),
],
"tests/test_visualisers.py": [
('    return Project.load(path)\n',
 '    from framerudiments.output_quality import OutputQuality\n'
 '    result = Project.load(path)\n'
 '    result.output_quality = OutputQuality({"enabled": False})\n'
 '    return result\n'),
],
"docs/visualisers.md": [
('## Pin and install the optional runtimes\n',
 '## Per-element feed and clean overlay routing\n\n'
 'FrameRudiments supports an optional project-level `visualiser_routing` object.\n'
 'It controls the **input RGBA texture** entering the first Butterchurn or\n'
 'projectM stage and independently decides which original layers are composited\n'
 'cleanly above the **last** visualiser result. The subsequent stages remain\n'
 'sequential: a later stage still receives the earlier stage\'s processed output.\n'
 'All unspecified elements retain continuous input and no clean overlay.\n'
 'This feature does not change a saved preset or reroute audio. See\n'
 '[the full routing guide](visualiser-routing.md) and the\n'
 '[CI demonstration gallery](https://kieransimkin.github.io/FrameRudiments/routing/).\n\n'
 '## Pin and install the optional runtimes\n'),
],
"docs/project-format.md": [
(' | `effects` |', ' | `effects` |'),  # optional no-op not used; remove below
],
"README.md": [
('## Install and run\n',
 '## Layer-selective Butterchurn/projectM feedback\n\n'
 'Each composited element can feed the GPU visualisers continuously, only\n'
 'during a bounded window measured in **64-pip source-clock beats**, or not at\n'
 'all. Independently, an element can render cleanly over the last stage.\n'
 'Word captions, lyric sprites, particle emitters, backgrounds and normal\n'
 'Rudiment layers use the same routing policy. Existing projects remain\n'
 'unchanged. [Configuration and examples](docs/visualiser-routing.md) ·\n'
 '[CI comparisons](https://kieransimkin.github.io/FrameRudiments/routing/).\n\n'
 '## Install and run\n'),
],
}
# Keep docs/project-format edit anchored to an exact existing row below.
EDITS["docs/project-format.md"] = [
 ('| `layers` | Ordered sprite, legacy bar and modular rudiment layers described below. |',
  '| `layers` | Ordered sprite, legacy bar and modular rudiment layers described below. |\n'
  '| `visualiser_routing` | Optional per-element GPU input/overlay policies. Feed continuously, only for first N native pips after visibility onset, or never; see [routing](visualiser-routing.md). |')
]
NEW_FILES = [
 "src/framerudiments/visualiser_routing.py", "tests/test_visualiser_routing.py",
 "scripts/generate_visualiser_routing_gallery.py", "docs/visualiser-routing.md"
]

# projectM pads portrait input into a square; routed transparent pixels must
# remain transparent in that overscan rather than burning opaque black.
EDITS["src/framerudiments/projectm_backend.py"].insert(0, (
    '            canvas = Image.new("RGBA", self.size, "black")\n'
    '            canvas.paste(frame, (self.crop_left, 0))',
    '            blank = (0, 0, 0, 0) if frame.getchannel("A").getextrema()[0] < 255 else "black"\n'
    '            canvas = Image.new("RGBA", self.size, blank)\n'
    '            canvas.paste(frame, (self.crop_left, 0))',
))
# CI both executes and publishes a machine-checked routing catalogue. Gallery
# image generation uses synthetic feedback with clear accuracy disclosures.
EDITS[".github/workflows/visualisation-gallery.yml"] = [
    ('tests/test_rich_subtitles.py tests/test_default_antialias.py tests/test_supersampling.py',
     'tests/test_rich_subtitles.py tests/test_default_antialias.py tests/test_supersampling.py tests/test_visualiser_routing.py'),
    ('scripts/generate_supersampling_gallery.py\n',
     'scripts/generate_supersampling_gallery.py src/framerudiments/visualiser_routing.py '
     'tests/test_visualiser_routing.py scripts/generate_visualiser_routing_gallery.py\n'),
    ('      - name: Generate source-level supersampling gallery\n'
     '        run: python scripts/generate_supersampling_gallery.py --output _site\n',
     '      - name: Generate source-level supersampling gallery\n'
     '        run: python scripts/generate_supersampling_gallery.py --output _site\n'
     '      - name: Generate Butterchurn/projectM layer-routing demonstrations\n'
     '        run: python scripts/generate_visualiser_routing_gallery.py --output _site\n'),
    ("          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n",
     "          routing = json.loads((p / 'routing/catalogue.json').read_text())\n"
     "          assert routing['synthetic'] and routing['real_gpu_render'] is False\n"
     "          assert len(routing['scenes']) == 12 and len(routing['frames']) == 5\n"
     "          assert (p / 'routing/index.html').is_file()\n"
     "          assert len(list((p / 'routing').glob('*/*.png'))) == 60\n"
     "          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n"),
]
