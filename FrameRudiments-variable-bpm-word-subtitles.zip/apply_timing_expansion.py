"""Safe, repeatable installer for FrameRudiments variable tempo + word LRC.

Dry-run every source anchor first. Does not overwrite unrelated modifications or
clobber distinct existing files; preserves Windows CRLF and UTF-8 BOM.
"""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from patch_spec import BASE, MODS, NEW


def apply(repo, package, *, check):
    repo = Path(repo).resolve()
    if not (repo / ".git").exists() or not (repo / "src/framerudiments/project.py").is_file():
        raise ValueError("Use a FrameRudiments Git checkout (or supply --repo)")
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          check=True, capture_output=True, text=True).stdout.strip()
    if head != BASE:
        print(f"Notice: prepared for main {BASE[:12]}, local HEAD {head[:12]}; checking every anchor")
    updates = {}
    for target, operations in MODS.items():
        path = repo / target
        raw = path.read_bytes()
        bom = raw.startswith(b"\xef\xbb\xbf")
        newline = "\r\n" if b"\r\n" in raw else "\n"
        original = raw.decode("utf-8-sig").replace("\r\n", "\n")
        modified = original
        for old, new in operations:
            found = modified.count(old)
            if modified.count(new) == 1:
                pass  # already applied; old insertion context may still remain
            elif found == 1:
                modified = modified.replace(old, new)
            else:
                raise ValueError(f"{target}: cannot match a unique source anchor; "
                                 "inspect local changes; no file has been written")
        if modified != original:
            data = modified.replace("\n", newline).encode("utf-8")
            updates[target] = (b"\xef\xbb\xbf" if bom else b"") + data
    for target in NEW:
        source = package / target
        data = source.read_bytes()
        dest = repo / target
        if dest.exists():
            if dest.read_bytes() != data:
                raise ValueError(f"{target} already exists with different content; refusing overwrite")
        else:
            updates[target] = data
    print(f"Validated {len(MODS)} modified paths and {len(NEW)} new files. "
          f"{len(updates)} paths need writing.")
    if check:
        print("Dry-run complete; nothing changed.")
        return
    # All conflicts have been detected, *before* any file is changed.
    for target, data in updates.items():
        path = repo / target
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".fr-timing-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
            os.replace(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
        print("Updated", target)
    print("Installation finished. Run pytest, ruff and GitHub CI before merging.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", default=".")
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    try:
        apply(args.repo, Path(__file__).resolve().parent, check=args.check)
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f"FrameRudiments timing patch: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
