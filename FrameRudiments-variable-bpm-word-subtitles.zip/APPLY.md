# FrameRudiments: variable BPM + per-word/line LRC patch

**Target:** `caebb34c59474829a4d888a14500f612811e6079` on `main` (particle-engine merged).

This package contains a baseline-aware, repeatable Windows-safe installer, new
modules, tests, a CI Pages timing example, and reference documentation. It
checks existing source anchors before writing, preserves CRLF, leaves unrelated
edits intact, and never silently replaces a conflicting new file.

## Windows PowerShell

Copy `FrameRudiments-variable-bpm-word-subtitles.zip` into the cloned repository,
then run:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/variable-bpm-word-subtitles
$pkg = Join-Path $env:TEMP 'FrameRudimentsTimingPatch'
Expand-Archive .\FrameRudiments-variable-bpm-word-subtitles.zip -DestinationPath $pkg -Force
py "$pkg\apply_timing_expansion.py" --repo . --check
py "$pkg\apply_timing_expansion.py" --repo .
python -m pip install -e '.[dev]'
python -m pytest -q tests/test_variable_bpm_words.py tests/test_beat_alignment.py tests/test_lyrics.py
python -m pytest -q
ruff check .
git diff --check
git status --short
```

**Do not apply if `--check` raises a source-context mismatch.** It doesn't
write anything before validation completes. Don't blindly discard existing
changes. `git status` should show source/test/doc files modified and new files
under the normal package directories. Commit and push this new feature branch,
then allow GitHub Actions to verify the full runner before merging.

To exercise Pages generation locally after installing dependencies and setting
the test font, create the base site before adding the timing page:

```powershell
python scripts/generate_visualisation_gallery.py --output _site
python scripts/generate_timing_gallery.py --output _site
```

The patch also corrects an existing CI error in
`scripts/generate_particle_gallery.py`: a source cue filename was being
prepended to the site root twice when the workflow uses a relative `_site`
output. The fix changes the file reference to be relative to its declared
`SyntheticProject.base` rather than changing any particle simulation logic.

## Feature contracts

- `clock.beat_timeline`: pinned StemLab `stemlab.beat-timeline.v1` with exact
  source identity, sample-frame anchors, 64 pips per beat and optional verified
  derived fields. `clock.bpm` remains a nominal hint if supplied; fixed BPM,
  older grid/alignment continue to work independently.
- `lyrics`: existing per-line LRC; `word_lyrics`: separate SHA-pinned .lrc with
  one-word-per-timestamp or enhanced inline word tags. Original audio clock.
- `captions.word_mode`: `off`, `highlight` (default when words available),
  `progressive`, or `current` (single word). Optional `word_colour` and
  `completed_colour` CSS colours. Word highlighting cannot be combined with
  `captions.mode=neighbours`.
- `word_captions`: separate text block for concurrent current-word subtitles.
  It may receive scoped post-effects using target `word-caption`.
- Renderer/preflight outputs: original `captions.srt`/`captions.ass` remain,
  plus `word-captions.srt` and `word-captions.ass` when word LRC is provided.
- CI Pages gallery: `https://kieransimkin.github.io/FrameRudiments/timing/`
  after a successful main merge and GitHub Pages deployment.

The isolated unit tests use no external private media or StemLab models. The
full compositor test requires the test font/native DanceRudiments environment
available in CI, and is explicitly skipped if not provided. The synthetic
Pages gallery is a demonstration, not verified song analysis or acoustic QA.
