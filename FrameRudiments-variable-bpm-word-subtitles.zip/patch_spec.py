"""Exact source transformations for FrameRudiments variable BPM and word LRC.

The installer checks *every* replacement before writing. Git patch is emitted
with context from the observed main-branch source, never fabricated paths.
"""
BASE = 'caebb34c59474829a4d888a14500f612811e6079'

MODS = {
'src/framerudiments/project.py': [
('from .beat_alignment import beat_alignment\n',
 'from .beat_alignment import beat_alignment\nfrom .beat_timeline import load_beat_timeline\nfrom .word_timing import parse_word_lrc, word_frame_ledger, assign_words_to_lines\n'),
('                      "identity", "effects", "post_effects", "stemlab_loop", "notes", "lyric_art", "canonical_lyrics"}, "project")',
 '                      "identity", "effects", "post_effects", "stemlab_loop", "notes", "lyric_art", "canonical_lyrics",\n'
 '                      "word_lyrics", "word_captions"}, "project")'),
('fields(cfg, {"bpm", "origin", "authority", "status", "phase_status", "beat_grid", "beat_alignment"}, "clock")',
 'fields(cfg, {"bpm", "origin", "authority", "status", "phase_status", "beat_grid", "beat_alignment",\n'
 '                     "beat_timeline"}, "clock")'),
('        self.alignment = None\n        if "beat_alignment" in cfg:\n',
 '        self.alignment = None\n'
 '        self.beat_timeline = None\n'
 '        if "beat_timeline" in cfg:\n'
 '            if any(key in cfg for key in ("beat_alignment", "beat_grid", "origin")):\n'
 '                raise ValueError("Variable beat timeline cannot combine with a second phase/BPM source")\n'
 '            if cfg["status"] == "synthetic":\n'
 '                raise ValueError("StemLab beat timeline cannot claim synthetic source authority")\n'
 '            ref = self.ref(cfg["beat_timeline"])\n'
 '            self.clock = load_beat_timeline(ref["path"], source_sha256=self.audio_ref["sha256"],\n'
 '                                            sample_rate=self.sample_rate, end_sample=self.end_sample)\n'
 '            if cfg.get("phase_status") not in (None, "estimated", "confirmed"):\n'
 '                raise ValueError("Beat timeline phase status must be estimated or confirmed")\n'
 '            if self.clock.review_status == "estimated" and (cfg["status"] != "estimated" or\n'
 '                                                              cfg.get("phase_status") == "confirmed"):\n'
 '                raise ValueError("Estimated beat timeline cannot claim confirmed tempo or phase")\n'
 '            if "bpm" in cfg:\n'
 '                number(cfg["bpm"], "Nominal BPM", minimum=0.00001)  # display hint only\n'
 '            self.beat_timeline = dict(self.clock.evidence, file=ref)\n'
 '        elif "beat_alignment" in cfg:\n'),
('        if (data.get("lyrics") or data.get("identity")) and not self.font_ref:\n',
 '        if (data.get("lyrics") or data.get("identity") or\n'
 '            (data.get("word_lyrics") and (data.get("captions") or data.get("word_captions")))) and not self.font_ref:\n'),
('        self.lyrics = self.ledger(parse_lrc(self.lyric_ref["path"])) if self.lyric_ref else []\n',
 '        self.lyrics = self.ledger(parse_lrc(self.lyric_ref["path"])) if self.lyric_ref else []\n'
 '        self.word_ref = self.ref(data["word_lyrics"]) if "word_lyrics" in data else None\n'
 '        if self.word_ref and Path(self.word_ref["path"]).suffix.lower() != ".lrc":\n'
 '            raise ValueError("word_lyrics must be a pinned .lrc file")\n'
 '        self.words = (word_frame_ledger(parse_word_lrc(self.word_ref["path"]),\n'
 '                    start_sample=self.start_sample, end_sample=self.end_sample,\n'
 '                    sample_rate=self.sample_rate, fps=self.fps, repeats=self.repeats,\n'
 '                    frame_count=self.frame_count) if self.word_ref else [])\n'
 '        if self.words and self.lyrics:\n'
 '            assign_words_to_lines(self.words, self.lyrics)\n'
 '        if "word_captions" in data and not self.word_ref:\n'
 '            raise ValueError("word_captions requires word_lyrics")\n'
 '        if data.get("captions", {}).get("word_mode", "off") != "off" and not self.word_ref:\n'
 '            raise ValueError("caption word_mode requires word_lyrics")\n'),
("                    clock={**self.data['clock'], 'alignment': self.alignment,\n"
 "                           'phase_status': self.alignment['phase_status'] if self.alignment else self.data['clock'].get('phase_status', 'unverified')},\n",
 "                    clock={**self.data['clock'], 'alignment': self.alignment,\n"
 "                           'beat_timeline': self.beat_timeline,\n"
 "                           'phase_status': self.alignment['phase_status'] if self.alignment else\n"
 "                               ('confirmed' if self.beat_timeline and self.beat_timeline['review_status'] == 'artist_confirmed'\n"
 "                                else self.data['clock'].get('phase_status', 'estimated' if self.beat_timeline else 'unverified'))},\n"),
('                    lyrics=self.lyrics, cues=self.cues, stemlab_loop=self.loop, effects=self.data.get("effects", []),\n',
 '                    lyrics=self.lyrics, cues=self.cues, stemlab_loop=self.loop, effects=self.data.get("effects", []),\n'
 '                    **({"word_timings": {"file": self.word_ref, "event_count": len(self.words)}}\n'
 '                       if self.word_ref else {}),\n'),
],
'src/framerudiments/compositor.py': [
('from PIL import Image, ImageDraw, ImageFont, ImageOps\n',
 'from PIL import Image, ImageColor, ImageDraw, ImageFont, ImageOps\n'),
('from .timeline import EventTrack\n',
 'from .timeline import EventTrack\nfrom .word_timing import WordTrack, draw_highlighted_line\n'),
('    cue: dict | None\n\n\nclass TextBlock:',
 '    cue: dict | None\n    word: dict | None = None\n\n\nclass TextBlock:'),
('        fields(config, {"box", "font_size", "min_font_size", "colour", "panel", "stroke", "mode",\n'
 '                        "line_spacing", "neighbour_colour"}, label)\n',
 '        fields(config, {"box", "font_size", "min_font_size", "colour", "panel", "stroke", "mode",\n'
 '                        "line_spacing", "neighbour_colour", "word_mode", "word_colour",\n'
 '                        "completed_colour"}, label)\n'),
('        if self.mode not in {"current", "neighbours"}:\n            raise ValueError("Caption mode must be current or neighbours")\n',
 '        if self.mode not in {"current", "neighbours"}:\n            raise ValueError("Caption mode must be current or neighbours")\n'
 '        self.word_mode = config.get("word_mode", "off")\n'
 '        if self.word_mode not in {"off", "highlight", "progressive", "current"}:\n'
 '            raise ValueError("word_mode must be off/highlight/progressive/current")\n'
 '        if self.word_mode != "off" and self.mode == "neighbours":\n'
 '            raise ValueError("Word highlighting is only supported with captions.mode=current")\n'
 '        for key in ("word_colour", "completed_colour"):\n'
 '            value = config.get(key, "#ffe082" if key == "word_colour" else "#9ad9d5")\n'
 '            if not isinstance(value, str):\n'
 '                raise ValueError(f"{key} must be a CSS colour")\n'
 '            ImageColor.getcolor(value, "RGBA")\n'),
('        self.lyrics, self.cues = EventTrack(project.lyrics), EventTrack(project.cues)\n',
 '        self.lyrics, self.cues = EventTrack(project.lyrics), EventTrack(project.cues)\n'
 '        self.words = WordTrack(project.words) if project.words else None\n'),
('        self.caption = TextBlock(project, project.data["captions"], label="captions") if "lyrics" in project.data else None\n',
 '        caption_config = dict(project.data.get("captions", {}))\n'
 '        if project.word_ref and caption_config and "word_mode" not in caption_config:\n'
 '            caption_config["word_mode"] = "highlight" if project.lyrics else "current"\n'
 '        self.caption = TextBlock(project, caption_config, label="captions") if caption_config and (\n'
 '            "lyrics" in project.data or project.word_ref) else None\n'
 '        self.word_caption = (TextBlock(project, project.data["word_captions"], label="word captions")\n'
 '                             if "word_captions" in project.data else None)\n'),
('        if self.caption:\n            targets.add("caption")\n',
 '        if self.caption:\n            targets.add("caption")\n'
 '        if self.word_caption:\n            targets.add("word-caption")\n'),
('    def context(self, frame):\n        p = self.project\n        return FrameContext(frame, frame / p.fps, p.source_time(frame), p.continuous_beat(frame),\n                            self.lyrics.at(frame), self.cues.at(frame))\n',
 '    def context(self, frame):\n'
 '        p = self.project\n'
 '        lyric = self.lyrics.at(frame)\n'
 '        word = self.words.at(frame, lyric if p.lyrics else None) if self.words else None\n'
 '        return FrameContext(frame, frame / p.fps, p.source_time(frame), p.continuous_beat(frame),\n'
 '                            lyric, self.cues.at(frame), word)\n'
 '\n'
 '    def _caption_draw(self, image, text, ctx):\n'
 '        if not self.words or self.caption.word_mode == "off":\n'
 '            return self.caption.draw(image, text)\n'
 '        state = self.words.state(ctx.frame, ctx.lyric if self.project.lyrics else None)\n'
 '        if self.caption.word_mode == "current":\n'
 '            return self.caption.draw(image, state["text"])\n'
 '        return draw_highlighted_line(\n'
 '            self.caption, image, text, active=state["active"],\n'
 '            completed=state["completed"] if self.caption.word_mode == "progressive" else (),\n'
 '            colour=self.caption.config.get("word_colour", "#ffe082"),\n'
 '            completed_colour=self.caption.config.get("completed_colour", "#9ad9d5"))\n'
 '\n'
 '    def _word_caption_draw(self, image, ctx):\n'
 '        state = self.words.state(ctx.frame, ctx.lyric if self.project.lyrics else None)\n'
 '        return self.word_caption.draw(image, state["text"])\n'),
('                def draw_caption(canvas):\n                    return self.caption.draw(canvas, text) or None\n',
 '                def draw_caption(canvas):\n                    return self._caption_draw(canvas, text, ctx) or None\n'),
('            self.text_states.setdefault(text, dict(first_frame=ctx.frame, bounds=text_bounds))\n\n        return pipeline.apply_frame(image, ctx)\n',
 '            if self.word_caption and self.words:\n'
 '                bounds = paint("word-caption", lambda canvas: self._word_caption_draw(canvas, ctx) or None)\n'
 '                if bounds:\n'
 '                    text_bounds.append(bounds)\n'
 '            self.text_states.setdefault(text, dict(first_frame=ctx.frame, bounds=text_bounds))\n'
 '        elif self.word_caption and self.words:\n'
 '            paint("word-caption", lambda canvas: self._word_caption_draw(canvas, ctx) or None)\n'
 '\n'
 '        return pipeline.apply_frame(image, ctx)\n'),
('                text_bounds.extend(self.caption.draw(image, text))\n',
 '                text_bounds.extend(self._caption_draw(image, text, ctx))\n'),
('            self.text_states.setdefault(text, dict(first_frame=frame, bounds=text_bounds))\n        return image.convert("RGB"), ctx\n',
 '            if self.word_caption and self.words:\n'
 '                text_bounds.extend(self._word_caption_draw(image, ctx))\n'
 '            self.text_states.setdefault(text, dict(first_frame=frame, bounds=text_bounds))\n'
 '        elif self.word_caption and self.words:\n'
 '            self._word_caption_draw(image, ctx)\n'
 '        return image.convert("RGB"), ctx\n'),
('                    custom_scene=bool(self.scene),\n',
 '                    custom_scene=bool(self.scene),\n'
 '                    **({"word_subtitles": {"enabled": True, "count": len(self.project.words),\n'
 '                       "highlight_mode": self.caption.word_mode if self.caption else "off",\n'
 '                       "separate_lane": self.word_caption is not None}} if self.words else {}),\n'),
],
'src/framerudiments/subtitles.py': [
('from pathlib import Path\n', 'from pathlib import Path\nimport re\n'),
('def export_subtitles(events, fps, frame_count, directory, width, height):\n',
 'def export_subtitles(events, fps, frame_count, directory, width, height, *, basename="captions"):\n'
 '    if not isinstance(basename, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,60}", basename):\n'
 '        raise ValueError("Invalid subtitle export name")\n'),
('    (directory / "captions.srt").write_text(srt + "\\n", encoding="utf-8")',
 '    (directory / f"{basename}.srt").write_text(srt + "\\n", encoding="utf-8")'),
('    (directory / "captions.ass").write_text(header + "\\n".join(lines) + "\\n", encoding="utf-8")',
 '    (directory / f"{basename}.ass").write_text(header + "\\n".join(lines) + "\\n", encoding="utf-8")'),
],
'src/framerudiments/render.py': [
('    export_subtitles(project.lyrics, project.fps, project.frame_count, output, project.width, project.height)\n',
 '    export_subtitles(project.lyrics, project.fps, project.frame_count, output, project.width, project.height)\n'
 '    if project.words:\n'
 '        from .word_timing import word_export_ledger\n'
 '        export_subtitles(word_export_ledger(project.words, project.lyrics), project.fps,\n'
 '                         project.frame_count, output, project.width, project.height,\n'
 '                         basename="word-captions")\n'),
],
'.github/workflows/visualisation-gallery.yml': [
('        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py tests/test_quality_effects.py tests/test_particle_engine.py\n',
 '        run: python -m pytest -q tests/test_advanced_renderers.py tests/test_visualisation_modulation.py tests/test_effect_batch.py tests/test_scoped_effects.py tests/test_sprite_renderers.py tests/test_quality_effects.py tests/test_particle_engine.py tests/test_variable_bpm_words.py\n'),
('        run: ruff check scripts/generate_visualisation_gallery.py',
 '        run: ruff check src/framerudiments/beat_timeline.py src/framerudiments/word_timing.py tests/test_variable_bpm_words.py scripts/generate_timing_gallery.py scripts/generate_visualisation_gallery.py'),
('      - name: Generate particles and smoke gallery\n        run: python scripts/generate_particle_gallery.py --output _site\n',
 '      - name: Generate particles and smoke gallery\n        run: python scripts/generate_particle_gallery.py --output _site\n'
 '      - name: Generate variable-tempo and word-timing gallery\n'
 '        run: python scripts/generate_timing_gallery.py --output _site\n'),
("          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n",
 "          timing = json.loads((p / 'timing/catalogue.json').read_text())\n"
 "          assert timing['synthetic'] and len(timing['scenes']) == 4\n"
 "          assert (p / 'timing/index.html').is_file()\n"
 "          assert len(list((p / 'timing').glob('*/*.png'))) == 16\n"
 "          sprites = json.loads((p / 'sprites/catalogue.json').read_text())\n"),
],
'scripts/generate_particle_gallery.py': [
('    reference = {"path": str(cues), "sha256": sha256(cues)}',
 '    reference = {"path": cues.name, "sha256": sha256(cues)}'),
],
'README.md': [
('## Install and run\n',
 '## Variable-tempo synchronisation and word subtitles\n\n'
 'FrameRudiments accepts a checksum-pinned `stemlab.beat-timeline.v1` in\n'
 '`clock.beat_timeline` for true piecewise BPM/beat phase at sample-frame anchors,\n'
 'matching StemLab and the opt-in DanceMoves variable-tempo API. Nominal/fixed\n'
 'BPM, beat grids, and fixed-tempo `beat_alignment` remain supported independently.\n'
 'Lyrics, cue timing and recorded Rudiments retain their source audio clock.\n'
 'A separate pinned `word_lyrics` LRC supports enhanced timestamps, per-word\n'
 'karaoke highlighting, progressive word colour and a distinct `word_captions`\n'
 'lane; line captions remain available through `lyrics`. Both per-line and\n'
 'per-word subtitle exports are generated with the same encoded frame ledger.\n'
 'See [variable-tempo and word LRC guide](docs/variable-bpm-word-subtitles.md)\n'
 'and the [synthetic public demo](https://kieransimkin.github.io/FrameRudiments/timing/).\n\n'
 '## Install and run\n'),
],
'docs/project-format.md': [
('## Optional full-frame effects\n',
 '## Variable tempo and dual LRC subtitle sources\n\n'
 '`clock.beat_timeline` is a pinned `stemlab.beat-timeline.v1` file: beat/sample\n'
 'anchors control procedural phase with local interval BPM and fractional pips,\n'
 'but must not be combined with `beat_alignment`, `beat_grid` or `origin`.\n'
 'A supplied `bpm` is a display hint, not the effective rhythm.\n'
 '`lyrics` remains the per-line LRC and `word_lyrics` is the optional,\n'
 'independently hashed per-word LRC. `captions.word_mode` may be `off`,\n'
 '`highlight`, `progressive` or `current`; the default with both files\n'
 'is `highlight`. `word_captions` is an independent text-block configuration\n'
 'for a second, simultaneously rendered word-only subtitle lane.\n'
 'See [variable BPM/word LRC guide](variable-bpm-word-subtitles.md).\n\n'
 '## Optional full-frame effects\n'),
],
}
NEW = [
 'src/framerudiments/beat_timeline.py', 'src/framerudiments/word_timing.py',
 'tests/test_variable_bpm_words.py', 'scripts/generate_timing_gallery.py',
 'docs/variable-bpm-word-subtitles.md',
]
