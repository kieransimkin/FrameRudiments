"""Exact-anchor update from FrameRudiments 56826c76."""
BASE = '56826c76eca2cc49696b483f53c6c000389a221c'
EDITS = {'src/framerudiments/project.py': [('from .word_timing import parse_word_lrc, word_frame_ledger, '
                                    'assign_words_to_lines\n',
                                    'from .word_timing import parse_word_lrc, word_frame_ledger, '
                                    'assign_words_to_lines\n'
                                    'from .output_quality import OutputQuality\n'),
                                   ('                      "word_lyrics", "word_captions", '
                                    '"word_indicator"}, "project")',
                                    '                      "word_lyrics", "word_captions", '
                                    '"word_indicator", "render_quality"}, "project")'),
                                   ('        self.inputs = []\n        self.audio = dict(data["audio"])',
                                    '        self.inputs = []\n'
                                    '        self.output_quality = '
                                    'OutputQuality(data.get("render_quality", {}))\n'
                                    '        self.audio = dict(data["audio"])'),
                                   ('                    **({"post_effects": self.data["post_effects"]} if '
                                    '"post_effects" in self.data else {}), inputs=self.inputs,\n',
                                    '                    **({"post_effects": self.data["post_effects"]} if '
                                    '"post_effects" in self.data else {}),\n'
                                    '                    render_quality=self.output_quality.evidence, '
                                    'inputs=self.inputs,\n')],
 'src/framerudiments/compositor.py': [('        self.project, self.scene = project, scene\n'
                                       '        self.effect_specs = effect_specs(project)',
                                       '        self.project, self.scene = project, scene\n'
                                       '        self.output_quality = project.output_quality\n'
                                       '        self.effect_specs = effect_specs(project)'),
                                      ('    def frame(self, frame):\n'
                                       '        if self.post_pipeline.temporal is not None',
                                       '    def _final_output(self, image, context, apply_quality):\n'
                                       '        # Historical shutter samples must not receive a separate '
                                       'AA pass.\n'
                                       '        if apply_quality and not getattr(self, '
                                       '"_temporal_sampling", False):\n'
                                       '            image = self.output_quality.apply(image)\n'
                                       '        return image, context\n'
                                       '\n'
                                       '    def frame(self, frame, *, apply_quality=True):\n'
                                       '        if self.post_pipeline.temporal is not None'),
                                      ('            return render_temporal_frame(self, frame)\n'
                                       '        ctx = self.context(frame)',
                                       '            image, context = render_temporal_frame(self, frame)\n'
                                       '            return self._final_output(image, context, '
                                       'apply_quality)\n'
                                       '        ctx = self.context(frame)'),
                                      ('            return matte.convert("RGB"), ctx\n'
                                       '        image = self.background.copy()',
                                       '            return self._final_output(matte.convert("RGB"), ctx, '
                                       'apply_quality)\n'
                                       '        image = self.background.copy()'),
                                      ('        return image.convert("RGB"), ctx\n'
                                       '\n'
                                       '    def frame_reports(self):',
                                       '        return self._final_output(image.convert("RGB"), ctx, '
                                       'apply_quality)\n'
                                       '\n'
                                       '    def frame_reports(self):'),
                                      ('        return dict(transformed_alpha_extents=self.extents, '
                                       'text_states=self.text_states,\n',
                                       '        return dict(transformed_alpha_extents=self.extents, '
                                       'text_states=self.text_states,\n'
                                       '                    '
                                       'render_quality=self.output_quality.evidence,\n'),
                                      ('    def draw(self, image, text, *, colour=None):\n'
                                       '        if not text:\n'
                                       '            return []\n'
                                       '        if self.rich is not None:',
                                       '    def draw(self, image, text, *, colour=None):\n'
                                       '        if not text:\n'
                                       '            return []\n'
                                       '        if getattr(getattr(self.project, "output_quality", None), '
                                       '"vector_scale", 1) > 1:\n'
                                       '            from .super_sampling import supersampled_text\n'
                                       '            return supersampled_text(self, image, text, '
                                       'colour=colour)\n'
                                       '        return self._draw_native(image, text, colour=colour)\n'
                                       '\n'
                                       '    def draw_styled(self, image, text, *, active=None, '
                                       'completed=()):\n'
                                       '        from .super_sampling import supersampled_text\n'
                                       '        return supersampled_text(self, image, text, active=active, '
                                       'completed=completed)\n'
                                       '\n'
                                       '    def _draw_native(self, image, text, *, colour=None):\n'
                                       '        if not text:\n'
                                       '            return []\n'
                                       '        if self.rich is not None:'),
                                      ('            return self.caption.rich.draw(\n'
                                       '                image, self.caption, text, '
                                       'active=state["active"],\n'
                                       '                completed=state["completed"] if '
                                       'self.caption.word_mode == "progressive" else ())',
                                       '            return self.caption.draw_styled(\n'
                                       '                image, text, active=state["active"],\n'
                                       '                completed=state["completed"] if '
                                       'self.caption.word_mode == "progressive" else ())'),
                                      ('        return draw_highlighted_line(\n'
                                       '            self.caption, image, text, active=state["active"],\n'
                                       '            completed=state["completed"] if self.caption.word_mode '
                                       '== "progressive" else (),\n'
                                       '            colour=self.caption.config.get("word_colour", '
                                       '"#ffe082"),\n'
                                       '            '
                                       'completed_colour=self.caption.config.get("completed_colour", '
                                       '"#9ad9d5"))',
                                       '        return self.caption.draw_styled(\n'
                                       '            image, text, active=state["active"],\n'
                                       '            completed=state["completed"] if self.caption.word_mode '
                                       '== "progressive" else ())'),
                                      ('        ctx = self.context(frame)\n'
                                       '        if self.post_pipeline.enabled:',
                                       '        if self.output_quality.time_samples > 1:\n'
                                       '            from .super_sampling import temporal_supersample\n'
                                       '            image, context = temporal_supersample(self, frame)\n'
                                       '            return self._final_output(image, context, '
                                       'apply_quality)\n'
                                       '        ctx = self.context(frame)\n'
                                       '        if self.post_pipeline.enabled:'),
                                      ('    def frame_reports(self):\n'
                                       '        reports = {layer.id: layer.frame_report',
                                       '    def frame_reports(self):\n'
                                       '        if hasattr(self, "_supersampled_reports"):\n'
                                       '            return dict(self._supersampled_reports)\n'
                                       '        reports = {layer.id: layer.frame_report')],
 'src/framerudiments/render.py': [('                image, context = compositor.frame(n)\n',
                                   '                image, context = compositor.frame(n, '
                                   'apply_quality=False)\n',
                                   2),
                                  ('                _analysis(analysis, compositor, context)\n',
                                   '                # Exactly one final AA pass, after optional GPU '
                                   'effects.\n'
                                   '                image = compositor.output_quality.apply(image)\n'
                                   '                _analysis(analysis, compositor, context)\n',
                                   2)],
 'scripts/generate_quality_gallery.py': [('from framerudiments.quality_effects import TemporalShutter, '
                                          'linear_shutter_composite\n',
                                          'from framerudiments.quality_effects import TemporalShutter, '
                                          'linear_shutter_composite\n'
                                          'from framerudiments.output_quality import OutputQuality\n'),
                                         ('SCENES = (\n'
                                          '    ("raw", "Original output", {}, None, "Unfiltered '
                                          'vector/raster samples"),',
                                          'SCENES = (\n'
                                          '    ("default-aa", "Highest default spatial and temporal '
                                          'quality", {}, None,\n'
                                          '     "4x source geometry + 8x true time samples + final edge '
                                          'treatment"),\n'
                                          '    ("default-off", "Explicit reduced-quality pixel-art path", '
                                          '{}, None,\n'
                                          '     "Disable the default supersampling and raster AA"),\n'
                                          '    ("raw", "Original output", {}, None, "Unfiltered '
                                          'vector/raster samples"),'),
                                         ('            _run(n, config, temporal, modulator=mods if name == '
                                          '"dancerudiment" else None).save(folder / f"{k}.png")',
                                          '            image = _run(n, config, temporal, modulator=mods if '
                                          'name == "dancerudiment" else None)\n'
                                          '            if name == "default-aa":\n'
                                          '                image = OutputQuality().apply(image)\n'
                                          '            elif name == "default-off":\n'
                                          '                image = OutputQuality({"enabled": '
                                          'False}).apply(image)\n'
                                          '            image.save(folder / f"{k}.png")'),
                                         ('    catalogue = '
                                          'dict(schema="framerudiments.synthetic-quality-gallery.v1", '
                                          'synthetic=True,\n'
                                          '                     measured_audio=False, '
                                          'frames=list(MOMENTS),',
                                          '    catalogue = '
                                          'dict(schema="framerudiments.synthetic-quality-gallery.v1", '
                                          'synthetic=True,\n'
                                          '                     '
                                          'default_render_quality=OutputQuality().evidence,\n'
                                          '                     measured_audio=False, '
                                          'frames=list(MOMENTS),')],
 '.github/workflows/visualisation-gallery.yml': [('tests/test_particle_engine.py '
                                                  'tests/test_variable_bpm_words.py '
                                                  'tests/test_rich_subtitles.py\n',
                                                  'tests/test_particle_engine.py '
                                                  'tests/test_variable_bpm_words.py '
                                                  'tests/test_rich_subtitles.py '
                                                  'tests/test_default_antialias.py '
                                                  'tests/test_supersampling.py\n'),
                                                 ('scripts/generate_rich_lyric_gallery.py '
                                                  'tests/test_rich_subtitles.py\n',
                                                  'scripts/generate_rich_lyric_gallery.py '
                                                  'tests/test_rich_subtitles.py '
                                                  'src/framerudiments/output_quality.py '
                                                  'src/framerudiments/super_sampling.py '
                                                  'tests/test_default_antialias.py '
                                                  'tests/test_supersampling.py '
                                                  'scripts/generate_supersampling_gallery.py\n'),
                                                 ("          assert len(quality['scenes']) >= 9 and "
                                                  "len(quality['visualisers']) >= 4\n",
                                                  "          assert len(quality['scenes']) >= 11 and "
                                                  "len(quality['visualisers']) >= 4\n"
                                                  '          assert '
                                                  "quality['default_render_quality']['enabled'] is True\n"
                                                  "          assert {'default-aa', 'default-off'} <= "
                                                  "{s['name'] for s in quality['scenes']}\n"),
                                                 ('      - name: Generate rich lyrics and word-indicator '
                                                  'gallery\n'
                                                  '        run: python '
                                                  'scripts/generate_rich_lyric_gallery.py --output _site\n',
                                                  '      - name: Generate rich lyrics and word-indicator '
                                                  'gallery\n'
                                                  '        run: python '
                                                  'scripts/generate_rich_lyric_gallery.py --output _site\n'
                                                  '      - name: Generate source-level supersampling '
                                                  'gallery\n'
                                                  '        run: python '
                                                  'scripts/generate_supersampling_gallery.py --output '
                                                  '_site\n'),
                                                 ('          quality = json.loads((p / '
                                                  "'quality/catalogue.json').read_text())\n",
                                                  '          supersampling = json.loads((p / '
                                                  "'supersampling/catalogue.json').read_text())\n"
                                                  "          assert supersampling['synthetic'] and not "
                                                  "supersampling['measured_audio']\n"
                                                  "          assert len(supersampling['scenes']) == 8 and "
                                                  "len(supersampling['frames']) == 4\n"
                                                  '          assert '
                                                  "supersampling['default']['spatial_scale'] == 4\n"
                                                  '          assert '
                                                  "supersampling['default']['temporal_samples'] == 8\n"
                                                  '          assert (p / '
                                                  "'supersampling/index.html').is_file()\n"
                                                  '          assert len(list((p / '
                                                  "'supersampling').glob('*/*.png'))) == 32\n"
                                                  '          quality = json.loads((p / '
                                                  "'quality/catalogue.json').read_text())\n")],
 'docs/project-format.md': [('| `word_lyrics`, `word_captions`, `word_indicator` | Word LRC source, '
                             'optional word lane, and word-following sprite/effects. |',
                             '| `word_lyrics`, `word_captions`, `word_indicator` | Word LRC source, '
                             'optional word lane, and word-following sprite/effects. |\n'
                             '| `render_quality` | High-quality default: 4× source-vector/font raster, 8 '
                             'distinct source-time samples per encoded frame and 3-pass edge-aware '
                             'finishing; explicit `enabled`, `spatial_scale` (1–4), `temporal_samples` '
                             '(1–8), and AA controls lower the quality for chosen projects. |')],
 'docs/quality-effects.md': [('FrameRudiments adds **opt-in, deterministic edge-aware anti-aliasing**, '
                              '**subpixel directional motion blur** and a distinct **encoded-frame '
                              'temporal shutter** to the existing `visual` / `post_effects` pipeline.',
                              'FrameRudiments offers **opt-in per-element edge-aware anti-aliasing**, '
                              '**subpixel directional motion blur** and a distinct **encoded-frame '
                              'temporal shutter** in the `visual` / `post_effects` pipeline.'),
                             ('Existing projects remain byte-for-byte unchanged unless the new effects are '
                              'enabled.',
                              'The *final output* additionally receives high-quality AA by default (a '
                              'change in output pixels); disable `render_quality` to recover unfiltered '
                              'output.'),
                             ('## Three different effects, not interchangeable methods\n',
                              '## High-quality source-level spatial and temporal supersampling\n'
                              '\n'
                              'The **default** rendering quality is 4× high-resolution rasterisation for\n'
                              'pinned TrueType/OpenType text, word-highlight masks and procedural-vector\n'
                              'Rudiment viewports, followed by Lanczos downsampling. Bitmap sprite modes\n'
                              'retain their verified source pixels rather than being incorrectly '
                              'described\n'
                              'as vector redraws. Other non-vector surfaces receive the final AA '
                              'treatment.\n'
                              'Motion is sampled eight times at different positions inside each target '
                              'frame\n'
                              'by an internal high-FPS compositor using the same pinned source-clock '
                              'inputs.\n'
                              'Native procedural motions interpolate fractional phases unless their '
                              'motion\n'
                              'config explicitly disables interpolation. The eight samples are averaged '
                              'in\n'
                              'linear light; they are **not** blended copies of one encoded frame. Source '
                              'audio\n'
                              'is never time-stretched, nor are variable-BPM maps or LRC times changed.\n'
                              'Word-indicator frame-duration fields are translated to the higher internal\n'
                              'sample rate, preserving their durations in seconds. Scene hooks that depend '
                              'on\n'
                              'integer frame indices see the original frame ordinal while fractional '
                              'source\n'
                              'seconds stay available for smooth custom movement. Optional GPU projectM '
                              'and\n'
                              'Butterchurn feedback still run once per encoded output frame, after the\n'
                              'Pillow subframe blend, so GPU-only motion cannot be subframe sampled.\n'
                              '\n'
                              '```json\n'
                              '{"render_quality": {"enabled": true, "spatial_scale": 4,\n'
                              '                    "temporal_samples": 8, "antialias": 1,\n'
                              '                    "antialias_radius": 0.75,\n'
                              '                    "antialias_threshold": 0.04, "antialias_passes": 3}}\n'
                              '```\n'
                              '\n'
                              'To deliberately reduce quality and rendering cost, set the two sample '
                              'counts\n'
                              'to 2 or 1, or use `{"render_quality":{"enabled":false}}` for unfiltered\n'
                              'pixels. The maximum defaults have substantial CPU and memory cost '
                              '(potentially\n'
                              'many times a previous release). The final edge-aware filter does not undo\n'
                              'badly aliased original bitmap assets. This is not optical-flow '
                              'interpolation,\n'
                              'and no unrecorded acoustic events are invented.\n'
                              '\n'
                              'See [spatiotemporal configuration and '
                              'limits](spatiotemporal-supersampling.md).\n'
                              '\n'
                              '## Three different effects, not interchangeable methods\n')],
 'tests/test_variable_bpm_words.py': [('    font_file = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"\n'
                                       '    if not Path(font_file).exists():\n'
                                       '        pytest.skip("Needs DejaVuSans for precise visual '
                                       'regression")',
                                       '    font_file = os.environ.get("FRAMERUDIMENTS_TEST_FONT")\n'
                                       '    if not font_file:\n'
                                       '        font_file = next((path for path in (\n'
                                       '            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",\n'
                                       '            "C:/Windows/Fonts/arialbd.ttf", '
                                       '"C:/Windows/Fonts/arial.ttf")\n'
                                       '            if Path(path).is_file()), None)\n'
                                       '    if not font_file or not Path(font_file).is_file():\n'
                                       '        pytest.skip("Requires an installed pinned test font")')],
 'README.md': [('## Install and run\n',
                '## Maximum-quality rendering enabled by default\n'
                '\n'
                'FrameRudiments now redraws pinned text outlines and procedural vector Rudiment\n'
                'views at **4× linear pixel resolution** before Lanczos reduction. It also\n'
                'renders **eight different source-clock subframes per output frame**,\n'
                'averaging them in linear light for true temporal supersampling. A final\n'
                'three-pass edge-aware AA filter runs after the optional GPU effect chain.\n'
                'These are the maximum supported preset settings and require no project changes.\n'
                'Explicitly lower them with `render_quality.spatial_scale` (1–4),\n'
                '`render_quality.temporal_samples` (1–8), or\n'
                '`render_quality.enabled: false` for deliberate pixel art or legacy output.\n'
                'Full-quality rendering can be much slower; read the\n'
                '[spatiotemporal sampling guide](docs/spatiotemporal-supersampling.md).\n'
                '\n'
                '## Install and run\n')],
 'src/framerudiments/rudiment_renderers.py': [('        self._styled_renderers = {}\n'
                                               '        self.renderer, identity = registry.create',
                                               '        self._styled_renderers = {}\n'
                                               '        self._hires_renderers = {}\n'
                                               '        self.renderer, identity = registry.create'),
                                              ('        viewport = renderer.render(self.data(context))\n'
                                               '        expected = self._size',
                                               '        scale = getattr(getattr(self.project, '
                                               '"output_quality", None), "vector_scale", 1)\n'
                                               '        if scale > 1 and not '
                                               'self._renderer_name.startswith("sprite-"):\n'
                                               '            from .super_sampling import vector_viewport\n'
                                               '            viewport, report = '
                                               'vector_viewport(self._registry, self._renderer_name,\n'
                                               '                self._size, style, self.data(context), '
                                               'scale, self.project, self._hires_renderers)\n'
                                               '        else:\n'
                                               '            viewport = '
                                               'renderer.render(self.data(context))\n'
                                               '            report = getattr(renderer, "frame_report", '
                                               'None)\n'
                                               '        expected = self._size'),
                                              ('        report = getattr(renderer, "frame_report", None)\n'
                                               '        if modulation_report:',
                                               '        if modulation_report:')],
 'src/framerudiments/lyric_indicator.py': [('def _profile(row, label):',
                                            'def _profile(row, label, time_factor=1):'),
                                           ('duration_frames=integer(row.get("duration_frames", 12), '
                                            'f"{label} duration", minimum=1, maximum=240))',
                                            'duration_frames=integer(row.get("duration_frames", 12), '
                                            'f"{label} duration", minimum=1, maximum=240 * time_factor))'),
                                           ('        self.travel = integer(config.get("travel_frames", 8), '
                                            '"indicator transition frames", maximum=120)',
                                            '        time_factor = getattr(project, '
                                            '"_time_sampling_factor", 1)\n'
                                            '        self.travel = integer(config.get("travel_frames", 8), '
                                            '"indicator transition frames",\n'
                                            '                              maximum=120 * time_factor)'),
                                           ('self.particle_lifetime = '
                                            'integer(particle.get("lifetime_frames", 35), "indicator '
                                            'particle lifetime", minimum=1, maximum=240)',
                                            'self.particle_lifetime = '
                                            'integer(particle.get("lifetime_frames", 35), "indicator '
                                            'particle lifetime",\n'
                                            '                                         minimum=1, '
                                            'maximum=240 * time_factor)'),
                                           ('        self.on_word = _profile(particle.get("on_word", {}), '
                                            '"word trigger")\n'
                                            '        self.on_cue = _profile(particle.get("on_cue", {}), '
                                            '"cue trigger")',
                                            '        self.on_word = _profile(particle.get("on_word", {}), '
                                            '"word trigger", time_factor)\n'
                                            '        self.on_cue = _profile(particle.get("on_cue", {}), '
                                            '"cue trigger", time_factor)')]}
NEW_FILES = ('src/framerudiments/output_quality.py',
 'src/framerudiments/super_sampling.py',
 'tests/test_default_antialias.py',
 'tests/test_supersampling.py',
 'scripts/generate_supersampling_gallery.py',
 'docs/spatiotemporal-supersampling.md')
