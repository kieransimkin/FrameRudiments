"""Build a strict-baseline Git patch using positional no-context hunks.

`apply_supersampling.py` is preferred: it performs exact-phrase conflict checks.
The git patch requires `git apply --unidiff-zero`, not plain git apply.
"""
from pathlib import Path
from patch_spec import BASE, EDITS, NEW_FILES

ROOT = Path(__file__).resolve().parent
HINTS = {
    "src/framerudiments/project.py": [[11], [25], [38], [183]],
    "src/framerudiments/compositor.py": [
        [209], [395], [398], [406], [441], [454],
        [87], [298], [302], [400], [447],
    ],
    "src/framerudiments/render.py": [[53, 88], [58, 93]],
    "src/framerudiments/rudiment_renderers.py": [[392], [446], [450]],
    "src/framerudiments/lyric_indicator.py": [[36], [45], [90], [137], [147]],
    "scripts/generate_quality_gallery.py": [[14], [27], [124], [127]],
    ".github/workflows/visualisation-gallery.yml": [[32], [34], [68], [47], [66]],
    "docs/project-format.md": [[17]],
    "docs/quality-effects.md": [[3], [3], [5]],
    "README.md": [[63]],
    "tests/test_variable_bpm_words.py": [[153]],
}


def rows(text):
    return text.splitlines()


def changes(path):
    if len(HINTS[path]) != len(EDITS[path]):
        raise ValueError(f"Hint mismatch: {path}: {len(HINTS[path])}/{len(EDITS[path])}")
    result = []
    for change, numbers in zip(EDITS[path], HINTS[path]):
        old, new = change[:2]
        oldrows, newrows = rows(old), rows(new)
        for n in numbers:
            result.append((n, oldrows, newrows))
    # Two substitution phrases on docs line 3: combine to avoid overlap.
    if path == "docs/quality-effects.md":
        first, second = EDITS[path][:2]
        original = ("FrameRudiments adds **opt-in, deterministic edge-aware anti-aliasing**, "
                    "**subpixel directional motion blur** and a distinct **encoded-frame temporal shutter** "
                    "to the existing `visual` / `post_effects` pipeline. Their parameters can be modulated "
                    "by independent native DanceRudiments, using the source clock and bounded history "
                    "already documented in [scoped post effects](scoped-post-effects.md). Existing "
                    "projects remain byte-for-byte unchanged unless the new effects are enabled.")
        combined = original.replace(first[0], first[1]).replace(second[0], second[1])
        result = [(3, [original], [combined]), result[2]]
    return sorted(result, key=lambda x:x[0])


def generate():
    patch = []
    for path in EDITS:
        if not EDITS[path]:
            continue
        patch.append(f"diff --git a/{path} b/{path}\n--- a/{path}\n+++ b/{path}\n")
        position, delta = 0, 0
        for line, oldrows, newrows in changes(path):
            if line <= position:
                raise ValueError(f"Overlapping patch at {path}:{line}")
            position = line + len(oldrows)-1
            patch.append(f"@@ -{line},{len(oldrows)} +{line+delta},{len(newrows)} @@\n")
            patch.extend("-" + x + "\n" for x in oldrows)
            patch.extend("+" + x + "\n" for x in newrows)
            delta += len(newrows) - len(oldrows)
    for path in NEW_FILES:
        content=(ROOT/path).read_text(encoding="utf-8").splitlines()
        patch.append(f"diff --git a/{path} b/{path}\nnew file mode 100644\n"
                     f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(content)} @@\n")
        patch.extend("+"+line+"\n" for line in content)
    target = ROOT/"FrameRudiments-spatiotemporal-supersampling.patch"
    target.write_text(''.join(patch),encoding="utf-8")
    return target

if __name__ == "__main__":
    file = generate()
    print(f"Created {file} ({file.stat().st_size:,} bytes) for {BASE[:12]}")
