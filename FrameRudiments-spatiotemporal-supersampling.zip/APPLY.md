# FrameRudiments 4× vector/text + 8× temporal supersampling

**Baseline:** `main` commit `56826c76eca2cc49696b483f53c6c000389a221c`.

**Important:** This is a *cumulative replacement* for the earlier unmerged
`FrameRudiments-default-antialias.zip`: do **not** apply both patches. This
package includes default final AA and the new real source-level supersampling.
Use a clean checkout of the listed baseline. If `main` has advanced, request a
retargeted patch rather than forcing a context-independent patch.

## Installation (PowerShell)

Place the ZIP in your FrameRudiments repository folder:

```powershell
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/max-quality-supersampling

$pkg = Join-Path $env:TEMP 'FrameRudimentsSupersampling'
Expand-Archive .\FrameRudiments-spatiotemporal-supersampling.zip -DestinationPath $pkg -Force

py "$pkg\apply_supersampling.py" --repo . --check
# Run only if the check succeeds:
py "$pkg\apply_supersampling.py" --repo .

python -m pip install -e '.[dev]'
python -m pytest -q --basetemp="$env:TEMP\fr-ssaa-tests" tests/test_default_antialias.py tests/test_supersampling.py
ruff check .
git diff --check
```

The installer preserves CRLF when present, fails on unrecognised conflicting
files, is safe to rerun, and verifies HEAD. **Do not use plain `git apply`:**
the standalone patch contains zero-context hunks and requires
`git apply --unidiff-zero --check` followed by `git apply --unidiff-zero`.
The installer is safer and validates all edited file anchors before writing.

## Default quality and explicit reduction

```json
{"render_quality": {"enabled": true, "spatial_scale": 4, "temporal_samples": 8,
  "antialias": 1, "antialias_radius": 0.75,
  "antialias_threshold": 0.04, "antialias_passes": 3}}
```

Those are the **maximum supported settings** and are used when omitted. To
reduce quality explicitly, set `spatial_scale:2` and `temporal_samples:4`, or
use `1`/`1`. `enabled:false` returns to opt-out/no default output AA. This is
appropriate for deliberate nearest-neighbour bitmap/pixel art.

See `docs/spatiotemporal-supersampling.md` for sources, limitations and
correct processing order. The CI-generated comparison page will appear under
`https://kieransimkin.github.io/FrameRudiments/supersampling/` only after the
patch merges and the Pages workflow deploys successfully.

## Test status

- Python compilation, synthetic Git patch apply, installer dry-run/repeat/conflict
  and **15 isolated unit tests** passed locally.
- CI-style gallery generator produced **8 scenes × 4 images**.
- Full native DanceRudiments, integration with all compositor plugins,
  Windows/Linux CI and encoded-video performance **have not been verified**.
  Review native CI before merging.
- Spatial source supersampling applies to pinned fonts and procedural-vector
  Rudiment viewports, *not* arbitrary bitmap assets or uninstrumented custom
  scene hook drawing. Temporal supersampling samples Python compositor motion,
  not projectM/Butterchurn GPU feedback at 8×.
