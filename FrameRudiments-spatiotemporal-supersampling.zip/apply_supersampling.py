"""Safe, exact-baseline FrameRudiments source-level supersampling installer.

Run --check first; all edits and new-file conflicts are validated before any
writes, and a repeated apply is a no-op. Never touches repository metadata.
"""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys

from patch_spec import BASE, EDITS, NEW_FILES


def _read(path):
    original = path.read_bytes()
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    remaining = original[len(bom):]
    text = remaining.decode("utf-8")
    newline = "\r\n" if b"\r\n" in remaining else "\n"
    return text.replace("\r\n", "\n"), bom, newline, original


def _plan(repo):
    head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo,
                          capture_output=True, text=True, check=True).stdout.strip()
    if head != BASE:
        raise ValueError(f"This patch targets commit {BASE}, but HEAD is {head}; "
                         "update main and avoid applying it to a different commit")
    pending = {}
    for relative, changes in EDITS.items():
        target = repo / relative
        if not target.is_file() or not target.resolve().is_relative_to(repo):
            raise ValueError(f"Missing or unsafe tracked file: {relative}")
        text, bom, newline, original = _read(target)
        updated = text
        for item in changes:
            old, new = item[:2]
            count = item[2] if len(item) > 2 else 1
            if updated.count(new) == count and old in new:
                continue
            if updated.count(old) == count:
                updated = updated.replace(old, new, count)
            elif updated.count(new) == count:
                continue
            else:
                raise ValueError(f"Patch conflict in {relative}: expected {count} occurrences "
                                 f"of {old[:80]!r}; found {updated.count(old)}")
        result = bom + updated.replace("\n", newline).encode("utf-8")
        if result != original:
            pending[target] = result
    base = Path(__file__).resolve().parent
    for relative in NEW_FILES:
        target = repo / relative
        source = base / relative
        data = source.read_bytes()
        if target.exists():
            if not target.is_file() or not target.resolve().is_relative_to(repo) or target.read_bytes() != data:
                raise ValueError(f"New-file conflict: {relative}")
        else:
            if not target.parent.resolve().is_relative_to(repo):
                raise ValueError(f"Unsafe destination: {relative}")
            pending[target] = data
    return pending


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--repo", type=Path, default=Path.cwd())
    cli.add_argument("--check", action="store_true")
    args = cli.parse_args()
    repo = args.repo.resolve()
    try:
        changes = _plan(repo)
        for target, content in changes.items():
            relative = target.relative_to(repo)
            print(f"{'CHECK' if args.check else 'WRITE'} {relative} "
                  f"({len(content):,} bytes, sha256 {hashlib.sha256(content).hexdigest()[:12]})")
        if args.check:
            print(f"Validation passed: {len(changes)} pending changes, no files modified")
            return 0
        for target, content in changes.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + ".supersampling-tmp")
            if temporary.exists():
                raise ValueError(f"Unexpected temporary destination: {temporary}")
            try:
                temporary.write_bytes(content)
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
        print("Spatial & temporal source supersampling installed; run tests and CI before merging")
        return 0
    except (ValueError, UnicodeError, OSError, subprocess.CalledProcessError) as exc:
        print(f"Cannot apply supersampling patch: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
